#!/usr/bin/python3
import sys
import struct
import wrapper
import threading
import time
from wrapper import recv_from_any_link, send_to_link, get_switch_mac, get_interface_name

def parse_ethernet_header(data):
    # Unpack the header fields from the byte array
    #dest_mac, src_mac, ethertype = struct.unpack('!6s6sH', data[:14])
    dest_mac = data[0:6]
    src_mac = data[6:12]
    
    # Extract ethertype. Under 802.1Q, this may be the bytes from the VLAN TAG
    ether_type = (data[12] << 8) + data[13]

    vlan_id = -1
    # Check for VLAN tag (0x8100 in network byte order is b'\x81\x00')
    if ether_type == 0x8200:
        vlan_tci = int.from_bytes(data[14:16], byteorder='big')
        vlan_id = vlan_tci & 0x0FFF  # extract the 12-bit VLAN ID
        ether_type = (data[16] << 8) + data[17]

    return dest_mac, src_mac, ether_type, vlan_id

def create_vlan_tag(vlan_id):
    # 0x8100 for the Ethertype for 802.1Q
    # vlan_id & 0x0FFF ensures that only the last 12 bits are used
    return struct.pack('!H', 0x8200) + struct.pack('!H', vlan_id & 0x0FFF)

def handle_bdpu_packet(bdpu, interface, interfaces, interface_to_vlan):
    global is_root
    global root_bridge_id
    global root_path_cost
    global own_bridge_id
    global root_port
    global blocked_ports

    bdpu_root_bridge_id = int.from_bytes(bdpu[22:30], byteorder='big')
    bdpu_sender_path_cost = int.from_bytes(bdpu[30:34], byteorder='big')
    bdpu_sender_bridge_id = int.from_bytes(bdpu[34:42], byteorder='big')

    was_root_bridge_id = root_bridge_id == own_bridge_id

    if int(bdpu_root_bridge_id) < int(root_bridge_id):
        is_root = False
        root_bridge_id = bdpu_root_bridge_id
        root_path_cost = bdpu_sender_path_cost + 10
        root_port = interface

        if was_root_bridge_id:
            for port in interfaces:
                if port != root_port and interface_to_vlan[get_interface_name(port)] == 'T':
                    blocked_ports[port] = True
    
        blocked_ports[root_port] = False

        for port in interfaces:
            if port != root_port and interface_to_vlan[get_interface_name(port)] == 'T':
                data, length = create_bdpu(interface, root_bridge_id, own_bridge_id, root_path_cost)
                send_to_link(interface, data, length)

    elif int(bdpu_root_bridge_id) == int(root_bridge_id):
        if interface == root_port and bdpu_sender_path_cost + 10 < root_path_cost:
            root_path_cost = bdpu_sender_path_cost + 10
        elif interface != root_port:
            if bdpu_sender_path_cost > root_path_cost:
                if blocked_ports[interface]:
                    blocked_ports[interface] = False
    elif int(bdpu_sender_bridge_id) == int(own_bridge_id):
        blocked_ports[interface] = True
    
    if own_bridge_id == root_bridge_id:
        for port in interfaces:
            blocked_ports[port] = False

def create_bdpu(interface, root_bridge_id, sender_bridge_id, sender_path_cost):
    DMA = 0x0180c2000000.to_bytes(6, byteorder='big')
    SMA = get_switch_mac()
    LT = 0x0026.to_bytes(2, byteorder='big')
    LLC_HEADER = 0x424203.to_bytes(3, byteorder='big')
    BDPU_CONFIG = struct.pack('5x') + int(root_bridge_id).to_bytes(8, byteorder='big')  \
                    + int(sender_path_cost).to_bytes(4, byteorder='big')                \
                    + int(sender_bridge_id).to_bytes(8, byteorder='big')                \
                    + int(interface).to_bytes(4, byteorder='big')                       \
                    + struct.pack('8x')

    return DMA + SMA + LT + LLC_HEADER + BDPU_CONFIG, 54

def send_bdpu_every_sec():
    global is_root
    global sender_bridge_id
    global root_bridge_id
    global interfaces
    global own_bridge_id

    is_root = True
    while True:
        time.sleep(1)
        if is_root == False:
            continue
        
        sender_bridge_id = own_bridge_id
        root_bridge_id = own_bridge_id
        for interface in interfaces:
            data, length = create_bdpu(interface, root_bridge_id, sender_bridge_id, 0)
            send_to_link(interface, data, length)
            
def read_config_file(file_path):
    try:
        interface_to_vlan = {}
        with open(file_path, 'r') as file:
            for line in file:
                words = line.split()

                if len(words) == 1:
                    property = words[0]
                else:
                    word1, word2 = words
                    interface_to_vlan[word1] = word2

            return property, interface_to_vlan
    except FileNotFoundError:
        print(f'The file {file_path} does not exist.')
    except Exception as e:
        print(f'Found error: {e}')

def is_unicast(dest_mac):
    return dest_mac != 'ff:ff:ff:ff:ff:ff'

def clean_frame(data, vlan, length):
    new_data = data[0:12] + data[16:]

    if vlan != -1:
        return new_data, length - 4

    return data, length

def compute_next_frame(data, sending_interface, received_interface, interface_to_vlan, vlan_received_frame, length):
    if (vlan_received_frame == -1):
        vlan_received_frame = interface_to_vlan[get_interface_name(received_interface)]

    vlan_sending_frame = interface_to_vlan[get_interface_name(sending_interface)]
    new_data = data
    new_length = length

    if vlan_sending_frame == 'T':
        new_data = data[0:12] + create_vlan_tag(int(vlan_received_frame)) + data[12:]
        return True, sending_interface, new_data, new_length + 4
    elif int(vlan_received_frame) == int(vlan_sending_frame):
        return True, sending_interface, new_data, new_length
    
    return False, None, None, None

is_root = True
root_bridge_id = 0
root_path_cost = 0
own_bridge_id = 0
root_port = 0
blocked_ports={}
interfaces = {}

def main():
    # init returns the max interface number. Our interfaces
    # are 0, 1, 2, ..., init_ret value + 1
    switch_id = sys.argv[1]

    global root_bridge_id
    global own_bridge_id
    global interfaces
    global blocked_ports

    num_interfaces = wrapper.init(sys.argv[2:])
    interfaces = range(0, num_interfaces)
    for port in interfaces:
        blocked_ports[port] = False

    id, interface_to_vlan = read_config_file('./configs/switch' + str(switch_id) + '.cfg')

    root_bridge_id = id
    own_bridge_id = id

    # Create and start a new thread that deals with sending BDPU
    t = threading.Thread(target=send_bdpu_every_sec)
    t.start()

    mac_table={}

    while True:
        interface, data, length = recv_from_any_link()
        dest_mac, src_mac, ethertype, vlan_id = parse_ethernet_header(data)

        # Print the MAC src and MAC dst in human readable format
        dest_mac = ':'.join(f'{b:02x}' for b in dest_mac)
        src_mac = ':'.join(f'{b:02x}' for b in src_mac)

        if dest_mac == '01:80:c2:00:00:00':
            handle_bdpu_packet(data, interface, interfaces, interface_to_vlan)
            continue

        mac_table[src_mac] = interface
        data, length = clean_frame(data, vlan_id, length)

        if is_unicast(dest_mac):
            if dest_mac in mac_table and blocked_ports[mac_table[dest_mac]] == False:
                can_send, port, new_data, new_length = compute_next_frame(data, mac_table[dest_mac], interface, interface_to_vlan, vlan_id, length)
                if can_send:
                    send_to_link(port, new_data, new_length)

            else:
                for port in interfaces:
                    if port != interface and blocked_ports[port] == False:
                        can_send, new_port, new_data, new_length = compute_next_frame(data, port, interface, interface_to_vlan, vlan_id, length)
                        if can_send:
                            send_to_link(new_port, new_data, new_length)
        else:
            for port in interfaces:
                if port != interface and blocked_ports[port] == False:
                    can_send, new_port, new_data, new_length = compute_next_frame(data, port, interface, interface_to_vlan, vlan_id, length)
                    if can_send:
                        send_to_link(new_port, new_data, new_length)

if __name__ == "__main__":
    main()
