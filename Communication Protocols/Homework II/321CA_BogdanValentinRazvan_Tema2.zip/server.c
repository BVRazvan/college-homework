#include <stdio.h>
#include <sys/socket.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/epoll.h>

#include "list.h"
#include "structs.h"
#include "helpers.h"
#include "tcp_helper.h"
#include "udp_helper.h"

#define BROADCAST -1
#define NOT_REGISTERED 0
#define REGISTERED 1
#define DISCONNECTED 2
#define WARNING_SIZE 25

static struct epoll_event ev_list[MAX_CONNECTIONS];
static uint32_t ev_len;
static struct epoll_event ev;
static int32_t epollfd;
static int32_t rc;
static struct in_addr ip_addr;
static struct tcp_client *new_tcp_client;
static char ip_addr_str[IP_BUFSIZE];
static struct list *tcp_clients = NULL;
static struct topic topics[MAX_TOPICS];
static uint32_t topics_len;
static struct tcp_client new_tcp_client_val;
static struct tcp_reply reply;
static struct tcp_request request;
static int32_t bytes_sent;
static int32_t bytes_recv;
static uint32_t offset;

/**
 * Free memory when the server is about to be closed.
 */
void free_and_close()
{
    for (uint32_t i = 0; i < topics_len; ++i) {
        free_list(topics[i].hard_links);
        free_list(topics[i].soft_links);
    }
    struct node *parc = tcp_clients->head, *aux = NULL;

    while (parc) {
        aux = parc->next;
        new_tcp_client = (struct tcp_client *)parc->info;
        if (new_tcp_client->active == REGISTER) {
            close(new_tcp_client->clientfd);
        }
        free_list(new_tcp_client->subscribed_topic);
        free(parc->info);
        free(parc);
        parc = aux;
    }
    free(tcp_clients);
}

/**
 * Change flags for a file descriptor in epoll.
 */
extern void modify_fd(int32_t *epollfd, struct epoll_event *new_ev,
                struct epoll_event *old_ev, uint32_t mask);

/**
 * Iterate through topics and then send the message to all clients subscribed
 * to this particular one.
 */
void send_to_subscribers(struct tcp_reply message, struct topic *topics, uint32_t len)
{
    struct node *parc;
    struct tcp_client *client;

    for (uint32_t i = 0; i < len; ++i) {
        if (!strcmp(message.message.topic, topics[i].title)) {
            parc = topics[i].soft_links->head;
            while (parc) {
                client = *(struct tcp_client **)parc->info;
                if (client->active == REGISTERED) {
                    add_element(client->subscribed_topic, &message, sizeof(message));

                    if (client->subscribed_topic->size == 1) {
                        ev.data.fd = client->clientfd;
                        modify_fd(&epollfd, &ev, &ev, EPOLLIN | EPOLLOUT);
                        client->particular_talk.send_bytes_remaining = client->particular_talk.send_len;
                        memcpy(client->particular_talk.send_buf, &message, sizeof(message));
                    }
                }
                parc = parc->next;
            }
            parc = topics[i].hard_links->head;
            while (parc) {
                client = *(struct tcp_client **)parc->info;
                add_element(client->subscribed_topic, &message, sizeof(message));

                if (client->active == REGISTERED && client->subscribed_topic->size == 1) {
                    ev.data.fd = client->clientfd;
                    modify_fd(&epollfd, &ev, &ev, EPOLLIN | EPOLLOUT);
                    client->particular_talk.send_bytes_remaining = client->particular_talk.send_len;
                    memcpy(client->particular_talk.send_buf, &message, sizeof(message));
                }
                parc = parc->next;
            }
        }
    }
}

/**
 * Send notification when server is closing.
 */
void send_exit_reply_particular(struct tcp_client *new_tcp_client)
{
    memset(new_tcp_client->particular_talk.send_buf, 0,
        sizeof(new_tcp_client->particular_talk.send_buf));
    new_tcp_client->particular_talk.send_bytes_remaining = new_tcp_client->particular_talk.send_len;

    while (new_tcp_client->particular_talk.send_bytes_remaining) {
        offset = new_tcp_client->particular_talk.send_len -
                    new_tcp_client->particular_talk.send_bytes_remaining;

        bytes_sent = send(new_tcp_client->clientfd, new_tcp_client->particular_talk.send_buf + offset,
                    new_tcp_client->particular_talk.send_bytes_remaining, 0);
        DIE(bytes_sent < 0, "send error\n");

        new_tcp_client->particular_talk.send_bytes_remaining -= bytes_sent;
    }
}

/**
 * Send a reply to clients when server is closed.
 */
void send_exit_reply_broadcast()
{
    struct node *parc;

    parc = tcp_clients->head;
    while (parc) {
        new_tcp_client = (struct tcp_client *)parc->info;
        if (new_tcp_client->active == REGISTERED) {
            send_exit_reply_particular(new_tcp_client);
        }
        parc = parc->next;
    }
    free_and_close();
}

/**
 * Try to register a user.
 */
void register_user(uint32_t fd)
{
    struct node *parc = NULL, *aux = NULL;

    memset(&ev, 0, sizeof(ev));
    parc = tcp_clients->head;
    while (parc) {
        new_tcp_client = (struct tcp_client *)parc->info;

        if (!strcmp(new_tcp_client->id_client, request.id_client)) {
            /**
             * Client already exists.
             */
            if (new_tcp_client->active == REGISTERED) {
                printf("Client %s already connected.\n", new_tcp_client->id_client);
                /**
                 * Remove the client and sent him a disconnection reply.
                 */
                while (parc) {  
                    new_tcp_client = (struct tcp_client *)parc->info;
                    if (new_tcp_client->active == NOT_REGISTERED && new_tcp_client->clientfd == fd) {
                        aux = parc;
                        parc = parc->next;

                        send_exit_reply_particular(new_tcp_client);
                        
                        rc = epoll_ctl(epollfd, EPOLL_CTL_DEL, new_tcp_client->clientfd, NULL);
                        close(new_tcp_client->clientfd);
                        remove_element(tcp_clients, aux);
                    } else {
                        parc = parc->next;
                    }
                }
                break;

            } else if (new_tcp_client->active == DISCONNECTED) {
                /**
                 * Client reconnects, update connection information.
                 */
                struct tcp_client *update = NULL;
                while (parc) {
                    update = (struct tcp_client *)parc->info;
                    if (update->clientfd == fd && update->active == NOT_REGISTERED) {
                        break;
                    }
                    parc = parc->next;
                }
                DIE(!update, "Should've been here!\n");
                
                memcpy(new_tcp_client->id_client, request.id_client, strlen(request.id_client));
                memset(&new_tcp_client->particular_talk, 0, sizeof(new_tcp_client->particular_talk));
                new_tcp_client->particular_talk.recv_len = sizeof(struct tcp_request);
                new_tcp_client->particular_talk.send_len = sizeof(struct tcp_reply);
                new_tcp_client->particular_talk.send_bytes_remaining = new_tcp_client->particular_talk.send_len;
                new_tcp_client->particular_talk.recv_bytes_remaining = new_tcp_client->particular_talk.recv_len;
                memcpy(&new_tcp_client->conn_info, &update->conn_info, sizeof(struct sockaddr_in));
                ip_addr.s_addr = update->conn_info.sin_addr.s_addr;
                DIE(inet_ntop(AF_INET, &ip_addr, ip_addr_str, sizeof(ip_addr_str)) == NULL, "inet_ntop error\n");

                printf("New client %s connected from %s:%u.\n", new_tcp_client->id_client,
                        ip_addr_str,ntohs(new_tcp_client->conn_info.sin_port));
                new_tcp_client->active = REGISTERED;
                new_tcp_client->clientfd = fd;
                ev.data.fd = new_tcp_client->clientfd;
                if (new_tcp_client->subscribed_topic->size) {
                    memcpy(new_tcp_client->particular_talk.send_buf,
                            new_tcp_client->subscribed_topic->head->info, sizeof(struct tcp_reply));
                    monitor_in_out(&epollfd, new_tcp_client->clientfd,
                                    ev_list, ev_len, &ev, EPOLLIN | EPOLLOUT);
                }

                remove_element(tcp_clients, parc);
                break;
            }
        } else if (new_tcp_client->active == NOT_REGISTERED && new_tcp_client->clientfd == fd) {
                /**
                 * It is indeed a new client.
                 */
                new_tcp_client->subscribed_topic = malloc(sizeof(*new_tcp_client->subscribed_topic));
                DIE(!new_tcp_client->subscribed_topic, "malloc error\n");

                memset(new_tcp_client->subscribed_topic, 0, sizeof(*new_tcp_client->subscribed_topic));

                memcpy(new_tcp_client->id_client, request.id_client, strlen(request.id_client));
                memset(&new_tcp_client->particular_talk, 0, sizeof(new_tcp_client->particular_talk));
                new_tcp_client->particular_talk.recv_len = sizeof(struct tcp_request);
                new_tcp_client->particular_talk.send_len = sizeof(struct tcp_reply);
                new_tcp_client->particular_talk.send_bytes_remaining = new_tcp_client->particular_talk.send_len;
                new_tcp_client->particular_talk.recv_bytes_remaining = new_tcp_client->particular_talk.recv_len;
                ip_addr.s_addr = new_tcp_client->conn_info.sin_addr.s_addr;
                DIE(inet_ntop(AF_INET, &ip_addr, ip_addr_str, sizeof(ip_addr_str)) == NULL, "inet_ntop error\n");

                printf("New client %s connected from %s:%u.\n", new_tcp_client->id_client, ip_addr_str,
                        ntohs(new_tcp_client->conn_info.sin_port));
                new_tcp_client->active = REGISTERED;

                break;
        }
        parc = parc->next;
    }
}

/**
 * Try to subscribe a user.
 */
void subscribe_user()
{
    struct node *parc = NULL;
    struct tcp_client *client = NULL;
    
    parc = tcp_clients->head;
    while (parc) {
        new_tcp_client = (struct tcp_client *)parc->info;
        if (!strcmp(new_tcp_client->id_client, request.id_client)) {
            client = new_tcp_client;
        }
        parc = parc->next;
    }
    DIE(!client, "The client should have been registered\n");

    struct tcp_client **addr;
    int8_t found = 0;
    
    addr = &client;
    for (uint32_t i = 0; i < topics_len; ++i) {
        if (!strcmp(topics[i].title, request.topic)) {
            found = 1;
            if (request.SF) {
                add_element(topics[i].hard_links, addr, sizeof(addr));
            } else {
                add_element(topics[i].soft_links, addr, sizeof(addr));
            }
            break;
        }
    }
    if (!found) {
        memcpy(topics[topics_len++].title, request.topic, sizeof(request.topic));
        topics[topics_len - 1].hard_links = malloc(sizeof(*topics[topics_len - 1].hard_links));
        DIE(!topics[topics_len - 1].hard_links, "malloc error\n");
        topics[topics_len - 1].soft_links = malloc(sizeof(*topics[topics_len - 1].soft_links));
        DIE(!topics[topics_len - 1].soft_links, "malloc error\n");
        memset(topics[topics_len - 1].hard_links, 0, sizeof(*topics[topics_len - 1].hard_links));
        memset(topics[topics_len - 1].soft_links, 0, sizeof(*topics[topics_len - 1].soft_links));

        if (request.SF) {
            add_element(topics[topics_len - 1].hard_links, addr, sizeof(addr));
        } else {
            add_element(topics[topics_len - 1].soft_links, addr, sizeof(addr));
        }
    }
}

/**
 * Try to unsubscribe a user.
 */
void unsubscribe_user()
{
    struct node *parc = NULL, *aux = NULL;
    struct tcp_client *client = NULL;

    parc = tcp_clients->head;
    while (parc) {
        new_tcp_client = (struct tcp_client *)parc->info;
        if (!strcmp(new_tcp_client->id_client, request.id_client)) {
            client = new_tcp_client;
        }
        parc = parc->next;
    }
    DIE(!client, "The client should have been registered\n");

    for (uint32_t i = 0; i < topics_len; ++i) {
        if (!strcmp(topics[i].title, request.topic)) {
            parc = topics[i].soft_links->head;
            while (parc) {
                new_tcp_client = *(struct tcp_client **)parc->info;
                if (new_tcp_client == client) {
                    aux = parc;
                    parc = parc->next;
                    remove_element(topics[i].soft_links, aux);
                    break;
                }
                parc = parc->next; 
            }
            parc = topics[i].hard_links->head;
            while (parc) {
                new_tcp_client = *(struct tcp_client **)parc->info;
                if (new_tcp_client == client) {
                    aux = parc;
                    parc = parc->next;
                    remove_element(topics[i].hard_links, aux);
                    break;
                }
                parc = parc->next; 
            }
            break;
        }
    }
}

/**
 * Try to remove a user.
 */
void exit_user()
{
    struct node *parc = NULL;
    struct tcp_client *client = NULL;

    parc = tcp_clients->head;
    while (parc) {
        new_tcp_client = (struct tcp_client *)parc->info;
        if (!strcmp(new_tcp_client->id_client, request.id_client)) {
                client = new_tcp_client;
                printf("Client %s disconnected.\n", new_tcp_client->id_client);
        }
        parc = parc->next;
    }
    DIE(!client, "The client should have been registered\n");
    client->active = DISCONNECTED;

    rc = epoll_ctl(epollfd, EPOLL_CTL_DEL, client->clientfd, NULL);
    DIE(rc < 0, "epoll_ctl error\n");
    close(client->clientfd);
}

/**
 * Handle the request received from the tcp client.
 */
void handle_request(struct tcp_request request, struct list* tcp_clients, uint32_t *len, int32_t fd)
{
    switch (request.command_type) {
        /**
         * Add a new client.
         */
        case REGISTER:
            register_user(fd);
            break;

        /**
         * Subscribe a client to a topic.
         */
        case SUBSCRIBE:
            subscribe_user();
            break;

        /**
         * Unsubscribe a client from a topic.
         */
        case UNSUBSCRIBE:
            unsubscribe_user();
            break;  
        
        /**
         * Remove a disconencted client.
         */
        case EXIT:
            exit_user();
            break;
            
        default:
            break;
    }
}

int main(int argc, char *argv[])
{
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    DIE(argc != 2, "Usage: ./server <port>\n");

    /**
     * Set tcp and udp sockets.
     */
    static int32_t listenfd;
    static int32_t udpfd;
    static int32_t cfd;
    static uint32_t addr_len = sizeof(struct sockaddr);
    static struct sockaddr_in c_addr_tcp;
    static uint16_t port;
    static struct sockaddr_in addr_tcp;
    static uint32_t enable = 1;
    static struct send_recv_message talks_udp;
    static struct sockaddr_in client_addr;
    static uint32_t client_len = sizeof(client_addr);
    static uint32_t tcp_clients_len = 0;
    static char stdin_buf[MESSAGE_BUFSIZE];

    tcp_clients = malloc(sizeof(*tcp_clients));
    DIE(!tcp_clients, "malloc error\n");

    memset(tcp_clients, 0, sizeof(*tcp_clients));

    rc = sscanf(argv[1], "%hu", &port);
    DIE(rc != 1, "Given port is invalid\n");

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(listenfd < 0, "socket() error\n");

    rc = setsockopt(listenfd, IPPROTO_TCP, TCP_NODELAY, &enable, sizeof(uint32_t));
    DIE(rc < 0, "setsockopt error\n");

    rc = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int));
    DIE(rc < 0, "setsockopt error\n");


    memset(&addr_tcp, 0, sizeof(struct sockaddr_in));
    addr_tcp.sin_family = AF_INET;
    addr_tcp.sin_port = htons(port);
    rc = inet_pton(AF_INET, HOST, &addr_tcp.sin_addr.s_addr);
    DIE(rc < 0, "inet_pton error\n");
    rc = bind(listenfd, (struct sockaddr *)&addr_tcp, sizeof(addr_tcp));
    DIE(rc < 0, "bind error\n");
    rc = listen(listenfd, MAX_CONNECTIONS);
    DIE(rc < 0, "listen error\n");

    set_udp_socket(&udpfd, argv[1]);

    /**
     * Create epoll instance and add listening tcp,udp sockets and stdin to it.
     */
    epollfd = epoll_create1(0);
    DIE(epollfd < 0, "epoll_create1 error\n");

    ev.data.fd = listenfd;
    ev.events = EPOLLIN;
    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, listenfd, &ev);
    DIE(rc < 0, "epoll_ctl error\n");

    ev.data.fd = STDIN_FILENO;
    ev.events = EPOLLIN;
    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, STDIN_FILENO, &ev);
    DIE(rc < 0, "epoll_ctl error\n");

    ev.data.fd = udpfd;
    ev.events = EPOLLIN;
    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, udpfd, &ev);
    DIE(rc < 0, "epoll_ctl error\n");

    memset(&talks_udp, 0, sizeof(talks_udp));
    talks_udp.recv_len = sizeof(struct udp_message);
    talks_udp.recv_bytes_remaining = talks_udp.recv_len;

    while (1) {
        ev_len = epoll_wait(epollfd, ev_list, MAX_CONNECTIONS, -1);
        DIE(ev_len < 0, "epoll_wait error\n");

        for (uint32_t i = 0; i < ev_len; ++i) {
            if (ev_list[i].events & EPOLLIN) {
                if (ev_list[i].data.fd == listenfd) {
                    /**
                     * Handle new connection from tcp client.
                     */
                    cfd = accept(listenfd, (struct sockaddr *)&c_addr_tcp,
                                    &addr_len);
                    DIE(cfd < 0, "accept error\n");

                    rc = setsockopt(cfd, IPPROTO_TCP, TCP_NODELAY, &enable, sizeof(uint32_t));
                    DIE(rc < 0, "setsockopt error\n");

                    memset(&new_tcp_client_val, 0, sizeof(new_tcp_client_val));
                    new_tcp_client_val.conn_info = c_addr_tcp;
                    new_tcp_client_val.clientfd = cfd;
                    new_tcp_client_val.active = NOT_REGISTERED;
                    new_tcp_client_val.particular_talk.recv_len = sizeof(struct tcp_request);
                    new_tcp_client_val.particular_talk.send_len = sizeof(struct tcp_reply);
                    new_tcp_client_val.particular_talk.recv_bytes_remaining = new_tcp_client_val.particular_talk.recv_len;
                    new_tcp_client_val.particular_talk.send_bytes_remaining = new_tcp_client_val.particular_talk.send_len;
                    add_element(tcp_clients, &new_tcp_client_val, sizeof(new_tcp_client_val));

                    memset(&ev, 0, sizeof(ev));
                    ev.data.fd = cfd;
                    ev.events = EPOLLIN;
                    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, cfd, &ev);
                    DIE(rc < 0, "epoll_ctl error\n");
                } else if (ev_list[i].data.fd == STDIN_FILENO) {
                    /**
                     * Handle new command from stdin (exit only).
                     */
                    memset(stdin_buf, 0, sizeof(stdin_buf));
                    bytes_recv = read(ev_list[i].data.fd, stdin_buf, sizeof(stdin_buf));
                    DIE(bytes_recv < 0, "read error\n");
                    
                    if (memcmp(stdin_buf, "exit", strlen("exit")) || strlen(stdin_buf) == strlen("exit")) {
                        fprintf(stderr, "Available command: exit\n");
                        continue;
                    }
                    send_exit_reply_broadcast();
                    exit(0);
                } else if (ev_list[i].data.fd == udpfd) {
                    /**
                     * Handle new message from udp client.
                     */
                    memset(talks_udp.recv_buf, 0, sizeof(talks_udp.recv_buf));
                    bytes_recv = recvfrom(ev_list[i].data.fd, talks_udp.recv_buf + talks_udp.recv_len - talks_udp.recv_bytes_remaining,
                                            talks_udp.recv_bytes_remaining, 0, (struct sockaddr *)&client_addr,
                                            &client_len);
                    DIE(bytes_recv < 0, "recv error\n");
                    talks_udp.recv_bytes_remaining -= bytes_recv;

                    /**
                     * Received an entire message, send it to subscribers.
                     */
                    memcpy(&reply.message, talks_udp.recv_buf, sizeof(reply.message));
                    reply.ip_udp = client_addr.sin_addr.s_addr;
                    reply.port_udp = client_addr.sin_port;

                    send_to_subscribers(reply, topics, topics_len);
                    talks_udp.recv_bytes_remaining = talks_udp.recv_len;
                } else {
                    /**
                     * Handle new request from tcp client.
                    */
                   struct send_recv_message *particular_talk = NULL;
                   struct node *parc = tcp_clients->head;
                
                   particular_talk = NULL;
                   while (parc) {
                       new_tcp_client = (struct tcp_client *)parc->info;
                       if (new_tcp_client->clientfd == ev_list[i].data.fd) {
                           particular_talk = &new_tcp_client->particular_talk;
                           break;
                       }
                       parc = parc->next;
                   }
                   DIE(!particular_talk, "Client should have been registered already\n");

                   if (particular_talk->recv_bytes_remaining == 0) {
                       particular_talk->recv_bytes_remaining = particular_talk->recv_len;
                   }

                   offset = particular_talk->recv_len - particular_talk->recv_bytes_remaining;
                   bytes_recv = recv(ev_list[i].data.fd, particular_talk->recv_buf + offset,
                                    particular_talk->recv_bytes_remaining, 0);
                   DIE(bytes_recv < 0, "recv error\n");

                   particular_talk->recv_bytes_remaining -= bytes_recv;
                   if (particular_talk->recv_bytes_remaining == 0) {
                       particular_talk->recv_bytes_remaining = particular_talk->recv_len;
                       request = *((struct tcp_request *)particular_talk->recv_buf);    
                       handle_request(request, tcp_clients, &tcp_clients_len, ev_list[i].data.fd);
                   }
                }
            } if (ev_list[i].events & EPOLLOUT) {
                /**
                 * Sent reply to the tcp client.
                 */
                struct node *parc = tcp_clients->head;

                new_tcp_client = NULL;
                while (parc) {
                    new_tcp_client = (struct tcp_client *)parc->info;
                    if (new_tcp_client->clientfd == ev_list[i].data.fd) {
                        break;
                    }
                    parc = parc->next;
                }

                DIE(!new_tcp_client, "Client should have been registered already\n");
                offset = new_tcp_client->particular_talk.send_len - new_tcp_client->particular_talk.send_bytes_remaining; 

                bytes_sent = send(ev_list[i].data.fd, new_tcp_client->particular_talk.send_buf + offset,
                            new_tcp_client->particular_talk.send_bytes_remaining, 0);
                DIE(bytes_sent < 0, "send error\n");

                new_tcp_client->particular_talk.send_bytes_remaining -= bytes_sent;
                if (new_tcp_client->particular_talk.send_bytes_remaining == 0) {
                    reply = *(struct tcp_reply *)new_tcp_client->subscribed_topic->head->info;

                    remove_element(new_tcp_client->subscribed_topic, new_tcp_client->subscribed_topic->head);
                    if (!new_tcp_client->subscribed_topic->size) {
                        modify_fd(&epollfd, &ev, &ev_list[i], EPOLLIN);

                    } else {
                        memcpy(new_tcp_client->particular_talk.send_buf,
                                new_tcp_client->subscribed_topic->head->info, sizeof(struct tcp_reply));
                        new_tcp_client->particular_talk.send_bytes_remaining = sizeof(struct tcp_reply);
                    }
                }
            }
        }
    }


    close(listenfd);
    close(udpfd);

    return 0;
}