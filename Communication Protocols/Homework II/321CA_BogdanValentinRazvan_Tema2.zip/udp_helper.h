#ifndef UDP_HELPER_H
#define UDP_HELPER_H

void set_udp_socket(int32_t *fd, char *port_argv);

#endif
