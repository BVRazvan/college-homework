#include <stdio.h>
#include <sys/socket.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/epoll.h>

#include "tcp_helper.h"
#include "helpers.h"

/**
 * Initiate tcp socket.
 */
void set_tcp_socket(uint32_t *fd, char *port_argv)
{
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);
    
    static uint32_t rc;
    static uint16_t port;
    static struct sockaddr_in addr_tcp;
    static uint32_t enable = 1;

    rc = sscanf(port_argv, "%hu", &port);
    DIE(rc != 1, "Given port is invalid\n");

    *fd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(*fd < 0, "socket() error\n");

    rc = setsockopt(*fd, IPPROTO_TCP, TCP_NODELAY, &enable, sizeof(uint32_t));
    DIE(rc < 0, "setsockopt error\n");

    memset(&addr_tcp, 0, sizeof(struct sockaddr_in));
    addr_tcp.sin_family = AF_INET;
    addr_tcp.sin_port = htons(port);
    rc = inet_pton(AF_INET, HOST, &addr_tcp.sin_addr.s_addr);
    DIE(rc < 0, "inet_pton error\n");
    rc = bind(*fd, (struct sockaddr *)&addr_tcp, sizeof(addr_tcp));
    DIE(rc < 0, "bind error\n");
    rc = listen(*fd, MAX_CONNECTIONS);
    DIE(rc < 0, "listen error\n");
}

/**
 * Handle situations when EPOLLOUT flag is no more needed (all requests have been sent)
 * or it is again needed (a new request appears and there aren't other in the queue)
 */
void modify_fd(int32_t *epollfd, struct epoll_event *new_ev,
                struct epoll_event *old_ev, uint32_t mask)
{
    new_ev->data.fd = old_ev->data.fd;
    new_ev->events = mask;

    int32_t rc = epoll_ctl(*epollfd, EPOLL_CTL_MOD, new_ev->data.fd, new_ev);
    DIE(rc < 0, "epoll_ctl error\n");
}

/**
 * Monitor particular flags for a file descriptor.
 */
void monitor_in_out(int32_t *epollfd, int32_t fd, struct epoll_event *ev_list,
                        int32_t ev_len, struct epoll_event *ev, int32_t mask)
{
    for (uint32_t j = 0; j < ev_len; ++j) {
        if (ev_list[j].data.fd == fd) {
            modify_fd(epollfd, ev, ev_list + j, mask);
            break;
        }
    }
}