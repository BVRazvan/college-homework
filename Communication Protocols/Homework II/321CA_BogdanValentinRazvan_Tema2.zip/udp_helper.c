#include <stdio.h>
#include <sys/socket.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>

#include "helpers.h"
#include "udp_helper.h"

/**
 * Inititate udp socket.
 */
void set_udp_socket(int32_t *fd, char *port_argv)
{
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);
    
    static uint32_t rc;
    static uint16_t port;
    static struct sockaddr_in addr_udp;

    *fd = socket(AF_INET, SOCK_DGRAM, 0);
    DIE(*fd < 0, "socket() error\n");

    rc = sscanf(port_argv, "%hu", &port);
    DIE(rc != 1, "Given port is invalid\n");

    memset(&addr_udp, 0, sizeof(struct sockaddr_in));
    addr_udp.sin_family = AF_INET;
    addr_udp.sin_addr.s_addr = INADDR_ANY;
    addr_udp.sin_port = htons(port);

    rc = bind(*fd, (struct sockaddr *)&addr_udp, sizeof(addr_udp));
    DIE(rc < 0, "bind error\n");

}