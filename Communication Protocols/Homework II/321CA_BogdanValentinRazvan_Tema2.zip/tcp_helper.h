#ifndef TCP_HELPER_H
#define TCP_HELPER_H

#include <stdio.h>
#include <sys/socket.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/epoll.h>

void set_tcp_socket(uint32_t *fd, char *port_argv);

void modify_fd(int32_t *epollfd, struct epoll_event *new_ev,
                struct epoll_event *old_fd, uint32_t mask);

void monitor_in_out(int32_t *epollfd, int32_t fd, struct epoll_event *ev_list,
                        int32_t ev_len, struct epoll_event *ev, int32_t mask);
#endif
