#ifndef STRUCTS_H
#define STRUCTS_H

#include <stdint.h>

#include "helpers.h"

#define ID_BUFSIZE 10
#define TOPIC_BUFSIZE 50
#define CONTENT_BUFSIZE 1500
#define MESSAGE_BUFSIZE 2000
#define IP_BUFSIZE 20
#define MAX_TOPICS 999

enum command {
    REGISTER,
    SUBSCRIBE,
    UNSUBSCRIBE,
    EXIT
};

/**
 * Used to create a tcp request.
 */
struct tcp_request {
    enum command command_type;
    char topic[TOPIC_BUFSIZE];
    char id_client[ID_BUFSIZE];
    uint8_t SF;
};

/**
 * Used to receive udp segments.
 */
struct udp_message {
    char topic[TOPIC_BUFSIZE];
    uint8_t type;
    char payload[CONTENT_BUFSIZE];
};

/**
 * Used to send tcp segments to clients.
 */
struct tcp_reply {
    uint32_t ip_udp;
    uint16_t port_udp;
    struct udp_message message;
} __attribute__((packed));

/**
 * Used to communicate with a client.
 */
struct send_recv_message {
    char send_buf[MESSAGE_BUFSIZE];
    char recv_buf[MESSAGE_BUFSIZE];
    uint32_t send_bytes_remaining;
    uint32_t recv_bytes_remaining;
    uint32_t send_len;
    uint32_t recv_len;
};

/**
 * Used to keep track of clients' details.
 */
struct tcp_client {
    char id_client[ID_BUFSIZE];
    uint8_t active;
    uint32_t clientfd;
    struct send_recv_message particular_talk;
    struct sockaddr_in conn_info;
    struct list *subscribed_topic;
};

/**
 * Used to store topics and clients subscribed
 * to these, depending of SF option(soft is used for SF = 0, hard is used for SF = 1).
 */
struct topic {
    char title[TOPIC_BUFSIZE];
    struct list *soft_links;
    struct list *hard_links;
};

#endif
