#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "helpers.h"

/**
 * Create new list.
 */
struct list *create_list()
{
    struct list *new_list = NULL;

    new_list = malloc(sizeof(*new_list));
    DIE(!new_list, "malloc error\n");

    new_list->head = NULL;
    new_list->size = 0;

    return new_list;
}

/**
 * Add a new element at the end of the list
 */
void add_element(struct list *l, void *info, uint32_t len)
{
    if (!l) {
        l = malloc(sizeof(*l));
        DIE(!l, "malloc error\n");
        memset(l, 0, sizeof(*l));
    }

    struct node *new_node = NULL;
    struct node *parc = l->head;

    new_node = malloc(sizeof(*new_node));
    DIE(!new_node, "malloc error\n");
    new_node->info = malloc(len * sizeof(char));
    DIE(!new_node->info, "malloc error\n");
    
    memset((char *)new_node->info, 0, len);

    new_node->next = NULL;
    memcpy(new_node->info, info, len);
    new_node->info_len = len;

    if (!parc) {
        l->head = new_node;
    } else {
        while (parc->next) {
            parc = parc->next;
        }
        parc->next = new_node;
    }
    ++l->size;
}

/**
 * Find a particular element in the list.
 */
struct node *find_element(struct list *l, void *info, uint32_t len)
{
    struct node *parc = l->head;

    while (parc) {
        if (len == parc->info_len && !memcmp(info, parc->info, parc->info_len)) {
            return parc;
        }
        parc = parc->next;
    }
    return NULL;
}

/**
 * Remove a particular element in the list.
 */
void remove_element(struct list *l, struct node *rem_node)
{
    if (!rem_node) {
        return;
    }
    struct node *parc = l->head;
    struct node *prev = NULL;

    --l->size;
    if (rem_node == l->head) {
        struct node *aux = l->head->next;
        free(l->head->info);
        free(l->head);
        l->head = aux;
    }
    else {
        while (parc) {
            if (parc == rem_node) {
                prev->next = rem_node->next;
                free(parc->info);
                free(parc);
                break;
            }
            prev = parc;
            parc = parc->next;
        }
    }
}

/**
 * Free the list.
 */
void free_list(struct list *l)
{
    if (!l) {
        return;
    }
    while (l->size) {
        remove_element(l, l->head);
    }
    free(l);
}
