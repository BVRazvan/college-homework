#ifndef LIST_H
#define LIST_H

#include <stdint.h>

struct node {
    void *info;
    uint32_t info_len;
    struct node *next;
};

struct list {
    struct node *head;
    uint32_t size;
};

struct list *create_list();

void add_element(struct list *l, void *info, uint32_t len);

void remove_element(struct list *l, struct node *rem_node);

struct node* find_element(struct list *l, void *info, uint32_t len);

void free_list(struct list *l);

#endif
