#include <stdio.h>
#include <sys/socket.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <fcntl.h>

#include "list.h"
#include "helpers.h"
#include "tcp_helper.h"
#include "structs.h"

#define MAX_ARGS 3
#define PORT_ARG 3
#define COMMAND_ARG 0
#define TOPIC_ARG 1
#define SF_ARG 2
#define ID_CLIENT_ARG 1
#define IP_SERVER_ARG 2
#define INT 0
#define SHORT_REAL 1
#define FLOAT 2
#define STRING 3

static struct list *queue = NULL;
static int32_t rc;

/**
 * Check if the client uses the commands correctly.
 */ 
char **check_args(char *command)
{
    char *delim = " \n";
    char *p = strtok(command, delim);
    uint32_t len = strlen(p) - 1;

    if ( (memcmp(p, "subscribe", strlen("subscribe")) || strlen("subscribe") != strlen(p)) &&  
         (memcmp(p, "unsubscribe", strlen("unsubscribe")) || strlen("unsubscribe") != strlen(p)) &&
         (memcmp(p, "exit", strlen("exit")) || strlen("exit") != strlen(p)) ) {
            fprintf(stderr, "Available commands are: subscribe, unsubscribe, exit\n");
            return NULL;
    }
    char **words;

    words = calloc(MAX_ARGS, sizeof(*words));
    DIE(!words, "calloc error\n");

    for (uint32_t i = 0; i < MAX_ARGS && p; ++i) {
        len = strlen(p);

        words[i] = calloc(len + 1, sizeof(*words[i]));
        DIE(!words[i], "calloc error\n");

        strncpy(words[i], p, len + 1);
        words[i][len] = '\0';
        
        p = strtok(NULL, delim);
    }
    int32_t valid = 1;


    if (!memcmp(words[COMMAND_ARG], "subscribe", strlen(words[COMMAND_ARG]) - 1)
        && (!words[SF_ARG] || p)) {
            fprintf(stderr, "Usage: subscribe <topic> <sf>\n");
            valid = 0;
        }

    if (!memcmp(words[COMMAND_ARG], "unsubscribe", strlen(words[COMMAND_ARG]) - 1)
        && ((!words[TOPIC_ARG]) || words[SF_ARG])) {
            fprintf(stderr, "Usage: unsubscribe <topic>\n");
            valid = 0;
        }

    if (!memcmp(words[COMMAND_ARG], "exit", strlen(words[COMMAND_ARG]) - 1)
        && words[TOPIC_ARG]) {
            fprintf(stderr, "Usage: exit\n");
            valid = 0;
        }

    if (!valid) {
        for (uint32_t i = 0; i < MAX_ARGS; ++i) {
            if (words[i]) {
                free(words[i]);
            }
        }
        free(words);

        return NULL;
    }

    return words;
}

/**
 * Create a request for the server based on command's parameters.
 */
struct tcp_request create_request(char **args, char *id_client)
{
    struct tcp_request request;

    memset(&request, 0, sizeof(request));
    if (!memcmp(args[COMMAND_ARG], "subscribe", strlen("subscribe"))) {
        request.command_type = SUBSCRIBE;
        memcpy(&request.topic, args[TOPIC_ARG], strlen(args[TOPIC_ARG]));
        request.SF = (args[SF_ARG][0] - '0');
    } else if (!memcmp(args[COMMAND_ARG], "unsubscribe", strlen("unsubscribe"))) {
        request.command_type = UNSUBSCRIBE;
        memcpy(&request.topic, args[TOPIC_ARG], strlen(args[TOPIC_ARG]));
    } else if (!memcmp(args[COMMAND_ARG], "exit", strlen("exit"))) {
        request.command_type = EXIT;
    }
    memcpy(request.id_client, id_client, strlen(id_client));

    for (uint32_t i = 0; i < MAX_ARGS; ++i) {
        free(args[i]);
    }
    free(args);

    return request;
}

void handle_reply(struct tcp_reply reply, char *ip_addr_str)
{
    switch (reply.message.type) {
        case INT: ;
            unsigned int payload_0 = *(unsigned int *)(reply.message.payload + 1);
            long int number = ntohl(payload_0);

            if (reply.message.payload[0] == 1) {
                number *= -1;
            }
            printf("%s:%hu - %s - INT - %ld\n", ip_addr_str, ntohs(reply.port_udp),
                    reply.message.topic, number);
            break;

        case SHORT_REAL: ;  
            unsigned short payload_1 = ntohs(*(unsigned short *)(reply.message.payload));

            printf("%s:%hu - %s - SHORT_REAL - %.2f\n", ip_addr_str, ntohs(reply.port_udp),
                    reply.message.topic, 1.0 * payload_1 / 100);
            break;
        
        case FLOAT: ;
            unsigned int payload_2 = *(unsigned int *)(reply.message.payload + 1);
            unsigned char payload_3 = *(unsigned char *)(reply.message.payload + 5);
            long long power_10 = 1;

            number = ntohl(payload_2);
            if (reply.message.payload[0] == 1) {
                number *= -1;
            }
            while (payload_3--) {
                power_10 *= 10LL;
            }

            printf("%s:%hu - %s - FLOAT - %lf\n", ip_addr_str, ntohs(reply.port_udp),
                    reply.message.topic, 1.0 * number / power_10);
            break;

        case STRING: ;
            printf("%s:%hu - %s - STRING - %s\n", ip_addr_str, ntohs(reply.port_udp),
                    reply.message.topic, reply.message.payload);
            break;

        default:
            break;
    }
}

int main(int argc, char *argv[])
{
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    DIE(argc != 4, "Usage: ./subscriber <id_client> <ip_server> <port_server>\n");

    DIE(strlen(argv[ID_CLIENT_ARG]) > 10, "id_client has more than 10 chars\n");
    
    static int32_t tcpfd;
    static uint16_t port;
    static int32_t epollfd;
    static int32_t bytes_sent;
    static uint32_t offset;
    static int32_t bytes_recv;
    static uint32_t enable = 1;
    static struct sockaddr_in addr_tcp;
    static struct epoll_event ev;
    static struct epoll_event ev_list[MAX_CONNECTIONS];
    static int32_t ev_len;
    static struct send_recv_message talks;
    static char stdin_buf[MESSAGE_BUFSIZE];
    static struct in_addr ip_addr;
    static char ip_addr_str[IP_BUFSIZE];

    memset(ev_list, 0, sizeof(ev_list));
    
    /**
     * Set tcp socket.
     */
    rc = sscanf(argv[PORT_ARG], "%hu", &port);
    DIE(rc != 1, "Given port is invalid\n");

    tcpfd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(tcpfd < 0, "socket() error\n");

    rc = setsockopt(tcpfd, IPPROTO_TCP, TCP_NODELAY, &enable, sizeof(uint32_t));
    DIE(rc < 0, "setsockopt error\n");

    memset(&addr_tcp, 0, sizeof(struct sockaddr_in));
    addr_tcp.sin_family = AF_INET;
    addr_tcp.sin_port = htons(port);
    rc = inet_pton(AF_INET, argv[IP_SERVER_ARG], &addr_tcp.sin_addr.s_addr);
    DIE(rc < 0, "inet_pton error\n");
    rc = connect(tcpfd, (struct sockaddr *)&addr_tcp, sizeof(struct sockaddr));
    DIE(rc < 0, "connect error\n");

    /**
     * Create epoll instance and add tcp socket and stdin to it.
     */
    epollfd = epoll_create1(0);
    DIE(epollfd < 0, "epoll_create1 error\n");

    ev.data.fd = tcpfd;
    ev.events = EPOLLIN | EPOLLOUT;
    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, tcpfd, &ev);
    DIE(rc < 0, "epoll_ctl error\n");

    ev.data.fd = STDIN_FILENO;
    ev.events = EPOLLIN;
    rc = epoll_ctl(epollfd, EPOLL_CTL_ADD, STDIN_FILENO, &ev);
    DIE(rc < 0, "epoll_ctl error\n");

    /**
     * Once the connection has been established, send a register message containing my id.
     */
    struct tcp_request request;
    struct tcp_reply reply;

    memset(&request, 0, sizeof(request));
    memset(&reply, 0, sizeof(reply));
    memset(&talks, 0, sizeof(talks));
    talks.send_len = sizeof(struct tcp_request);
    talks.recv_len = sizeof(struct tcp_reply);
    request.command_type = REGISTER;
    memcpy(request.id_client, argv[ID_CLIENT_ARG], strlen(argv[ID_CLIENT_ARG]));
    talks.send_bytes_remaining = talks.send_len;
    talks.recv_bytes_remaining = talks.recv_len;
    memcpy(talks.send_buf, &request, sizeof(request));

    /**
     * Create a queue of tcp requests.
     */
    queue = malloc(sizeof(*queue));
    DIE(!queue, "malloc error\n");

    memset(queue, 0, sizeof(*queue));
    add_element(queue, &request, sizeof(request));

    while (1) {
        ev_len = epoll_wait(epollfd, ev_list, MAX_CONNECTIONS, -1);
        DIE(ev_len < 0, "epoll_wait error\n");
        for (uint32_t i = 0; i < ev_len; ++i) {
            if (ev_list[i].events & EPOLLIN) {
                if (ev_list[i].data.fd == tcpfd) {
                    /**
                     * Handle new message from server.
                     */
                    bytes_recv = recv(ev_list[i].data.fd, talks.recv_buf + talks.recv_len - talks.recv_bytes_remaining,
                                talks.recv_bytes_remaining, 0);
                    DIE(bytes_recv < 0, "recv error\n");

                    talks.recv_bytes_remaining -= bytes_recv;
                    
                    /**
                     * Received a reply, print it.
                     */
                    reply = *(struct tcp_reply *)talks.recv_buf;
                    
                    /**
                     * Received an empty reply meaning that server was closed.
                     */
                    if (!reply.ip_udp) {
                        close(tcpfd);
                        free_list(queue);
                        exit(0);
                    }
                    ip_addr.s_addr = reply.ip_udp;

                    DIE(inet_ntop(AF_INET, &ip_addr, ip_addr_str, sizeof(ip_addr_str)) == NULL, "inet_ntop error\n");
                    handle_reply(reply, ip_addr_str);

                    talks.recv_bytes_remaining = talks.recv_len;
                    memset(&reply, 0, sizeof(reply));

                } else if (ev_list[i].data.fd == STDIN_FILENO) {
                    /**
                     * Handle new command from stdin.
                     */
                    memset(stdin_buf, 0, sizeof(stdin_buf));
                    bytes_recv = read(ev_list[i].data.fd, stdin_buf, sizeof(stdin_buf));
                    DIE(bytes_recv < 0, "read error\n");

                    char **words = check_args(stdin_buf);

                    if (!words) {
                        continue;
                    }

                    memset(&request, 0, sizeof(request));
                    request = create_request(words, argv[ID_CLIENT_ARG]);
                    add_element(queue, &request, sizeof(request));
                    
                    /**
                     * If this is the only command in the queue it means that
                     * the EPOLLOUT flag is disabled and it needs to be active.
                     */
                    if(queue->size == 1) {
                        ev.data.fd = tcpfd;
                        modify_fd(&epollfd, &ev, &ev, EPOLLIN | EPOLLOUT);
                        talks.send_bytes_remaining = sizeof(struct tcp_request);
                        memcpy(talks.send_buf, queue->head->info, sizeof(talks.send_buf));
                    }
                }
            }
            if (ev_list[i].events & EPOLLOUT) {
                /**
                 * Send request to the server.
                 * Once all bytes of a request have been sent, print a notification
                 * and it's no longer needed to monitor EPOLLOUT.
                 */
                offset = talks.send_len - talks.send_bytes_remaining;
                bytes_sent = send(ev_list[i].data.fd,
                        talks.send_buf + offset, talks.send_bytes_remaining, 0);
                DIE(bytes_sent < 0, "send error\n");

                talks.send_bytes_remaining -= bytes_sent;
                if (talks.send_bytes_remaining == 0) {
                    request = *(struct tcp_request *)queue->head->info;
                    request.topic[strlen(request.topic)] = '\0';

                    if (request.command_type == SUBSCRIBE) {
                        printf("Subscribed to topic.\n");
                    } else if (request.command_type == UNSUBSCRIBE) {
                        printf("Unsubscribed from topic.\n");
                    } else if (request.command_type == EXIT) {
                        free_list(queue);
                        close(epollfd);
                        close(tcpfd);
                        exit(0);
                    }
                    talks.send_bytes_remaining = sizeof(struct tcp_request);
                    remove_element(queue, queue->head);
                    if (!queue->size) {
                        modify_fd(&epollfd, &ev, &ev_list[i], EPOLLIN);

                        continue;
                    } else {
                        memcpy(talks.send_buf, queue->head->info, sizeof(struct tcp_request));
                    }
                }
            }
        }
    }

    close(epollfd);
    close(tcpfd);

    return 0;
}
