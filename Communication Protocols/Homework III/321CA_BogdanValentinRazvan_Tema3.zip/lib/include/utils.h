#ifndef UTILS_H
#define UTILS_H

#pragma once

#include <stdint.h>
#include <cstdio>
#include <string>
#include <cstring>

/* ############# USEFUL MACROS ########## */
#ifdef DEBUG
#define DEBUG_PRINT(fmt, args...)    fprintf(stderr, fmt, ## args)
#else
#define DEBUG_PRINT(fmt, args...)    /* Don't do anything in release builds */
#endif

/* Can be used to update the timeout */
#define TIMEOUT_SEND(delay) (delay == 0 ? 100 : delay / 2 + 30)

/* Used to convert a char array to a string */
std::string convert_char_to_string(std::string sol, char *buf, int len);

/* Used to convert a string to a char array */
void convert_string_to_char(std::string str, char *buf, int len);

#endif

