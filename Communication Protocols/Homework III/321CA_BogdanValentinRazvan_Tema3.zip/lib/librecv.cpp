#include <pthread.h>
#include <cstdlib>
#include <map>
#include <cstdint>
#include "include/lib.h"
#include "utils.h"
#include "protocol.h"
#include <poll.h>
#include <cassert>
#include <sys/timerfd.h>
#include <cstring>
#include <errno.h>
#include <string>
#include <unistd.h>
#include <unordered_map>

using namespace std;

std::map<int, struct connection *> cons;
std::unordered_map<uint16_t, int > mp_addrs;

struct pollfd data_fds[MAX_CONNECTIONS];
/* Used for timers per connection */
struct pollfd timer_fds[MAX_CONNECTIONS];
int fdmax = 0, buffer_len = 0, cons_fd = 0;
struct sockaddr_in server_addrs;
string receive_string;
struct poli_tcp_data_hdr header_data;
struct poli_tcp_ctrl_hdr header_ctrl;

struct poli_tcp_ctrl_hdr create_new_ctrl_segment(int conn_id, int ack)
{
    struct poli_tcp_ctrl_hdr ack_message;
    ack_message.protocol_id = POLI_PROTOCOL_ID;
    ack_message.conn_id = cons[conn_id]->conn_id;
    ack_message.type = ACK;
    ack_message.ack_num = ack;
    ack_message.recv_window = cons[conn_id]->buff_size;

    return ack_message;
}

int recv_data(int conn_id, char *buffer, int len)
{
    int size = 0;
    bool found = false;
    struct poli_tcp_data_hdr header_data;
    char segment[MAX_SEGMENT_SIZE];

    do {
        /* Wait for in order segment */
        for (size_t i = 0; i < cons[conn_id]->recv_seg.size(); ++i) {
            convert_string_to_char(cons[conn_id]->recv_seg[i], segment, MAX_SEGMENT_SIZE);
            header_data = *(struct poli_tcp_data_hdr *)segment;
            if (header_data.seq_num == cons[conn_id]->last_read + 1) {
                found = true;
            }
        }
    } while (found == false);

    pthread_mutex_lock(&cons[conn_id]->con_lock);
    /* We will write code here as to not have sync problems with recv_handler */
    /* Remove len data from the buffer */
    for (size_t i = 0; i < cons[conn_id]->recv_seg.size(); ++i) {
        convert_string_to_char(cons[conn_id]->recv_seg[i], segment, MAX_SEGMENT_SIZE);
        header_data = *(struct poli_tcp_data_hdr *)segment;
        if (header_data.seq_num == cons[conn_id]->last_read + 1) {
            ++cons[conn_id]->last_read;
            cons[conn_id]->buff_size += MAX_SEGMENT_SIZE;
            memcpy(buffer + size, segment + sizeof(struct poli_tcp_data_hdr), header_data.len);
            cons[conn_id]->recv_seg.erase(cons[conn_id]->recv_seg.begin() + i);
            size = header_data.len;

            break;
        }
    }
    pthread_mutex_unlock(&cons[conn_id]->con_lock);

    return size;
}

void show_segment(char *buffer)
{
    header_data = *(struct poli_tcp_data_hdr *)buffer;
    printf("Protocol: %hhu\n", header_data.protocol_id);
    printf("Conn_id: %hhu\n", header_data.conn_id);
    printf("Type: %hhu\n", header_data.type);
    printf("Seq_num: %hu\n", header_data.seq_num);
    printf("Len: %hu\n", header_data.len);
    printf("\n");
}

void send_syn_ack_segment(struct connection *con)
{
    int ret;
    struct poli_tcp_ctrl_hdr syn_ack_message;
    memset(&syn_ack_message, 0, sizeof(syn_ack_message));
    syn_ack_message.protocol_id = POLI_PROTOCOL_ID;
    syn_ack_message.conn_id = fdmax;
    syn_ack_message.type = SYN | ACK;
    syn_ack_message.ack_num = 1;
    char payload[MAX_DATA_SIZE];
    memset(payload, 0, sizeof(payload));
    sprintf(payload, "%d", con->port);

    char giveback[MAX_SEGMENT_SIZE];
    memset(giveback, 0, sizeof(giveback));
    memcpy(giveback, &syn_ack_message, sizeof(syn_ack_message));
    memcpy(giveback + sizeof(syn_ack_message), payload, sizeof(payload));
    ret = sendto(con->sockfd, giveback, sizeof(giveback)
                , 0, (struct sockaddr *)&con->servaddr, sizeof(con->servaddr));
    memset(giveback, 0, sizeof(giveback));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }
}

int check_three_way_handshake(struct connection *con, struct poli_tcp_data_hdr header_data)
{
    if (header_data.type == SYN) {
        con->got_syn = 1;
        send_syn_ack_segment(con);
        return 1;
    } else if (header_data.type == ACK) {
        con->got_ack = 1;
        con->did_connect = 1;
        return 1;
    }
    return 0;
}

int try_three_way_handshake(struct connection *con)
{
    if (con->got_syn && !con->got_ack) {
        send_syn_ack_segment(con);
        return 1;
    }
    return 0;
}

void *receiver_handler(void *arg)
{

    char segment[MAX_SEGMENT_SIZE];
    int res, ret = 0;
    DEBUG_PRINT("Starting recviver handler\n");

    while (1) {

        int conn_id = -1, try_con = 0;
        do {
            res = recv_message_or_timeout(segment, MAX_SEGMENT_SIZE, &conn_id);
        } while(res == -14);

        pthread_mutex_lock(&cons[conn_id]->con_lock);
        /* Handle segment received from the sender. We use this between locks
        as to not have synchronization issues with the recv_data calls which are
        on the main thread */

        /* As a new event occured, handle it based on res */
        header_data = *(struct poli_tcp_data_hdr *)segment;
        switch(res) {
            case -1:
                try_con = try_three_way_handshake(cons[conn_id]);
                if (try_con) {
                    goto end;
                }
                header_ctrl = create_new_ctrl_segment(conn_id, cons[conn_id]->last_ack);
                break;

            default:
                receive_string = "";
                receive_string = convert_char_to_string(receive_string, segment, MAX_SEGMENT_SIZE);

                try_con = check_three_way_handshake(cons[conn_id], header_data);
                if (try_con) {
                    goto end;
                }

                /* Received out of window segment */
                if (header_data.seq_num > cons[conn_id]->last_read +
                                            cons[conn_id]->max_buff_size / MAX_SEGMENT_SIZE) {
                        goto end;
                }
                /* Received ACK-ed segment, sent the ACK again */
                else if (header_data.seq_num <= cons[conn_id]->last_ack) {
                    header_ctrl = create_new_ctrl_segment(conn_id, header_data.seq_num);
                    if (header_data.seq_num == cons[conn_id]->last_ack) {
                        ++cons[conn_id]->last_ack;
                    }
                } else {
                    /* Received in range segment */
                    if ((size_t)cons[conn_id]->buff_size < MAX_SEGMENT_SIZE) {
                        goto end;
                    }
                    if (!cons[conn_id]->stored_seg[header_data.seq_num]) {
                        cons[conn_id]->recv_seg.push_back(receive_string);
                        cons[conn_id]->stored_seg[header_data.seq_num] = true;
                        cons[conn_id]->buff_size -= MAX_SEGMENT_SIZE;
                    }
                    header_ctrl = create_new_ctrl_segment(conn_id, header_data.seq_num);
                }
                ret = sendto(cons[conn_id]->sockfd, &header_ctrl, sizeof(header_ctrl), 0,
                                (struct sockaddr *)&cons[conn_id]->servaddr,
                                    sizeof(cons[conn_id]->servaddr));
                if (ret < 0) {
                    printf("error found!\n");
                    exit(-1);
                }
                break;
        }
end:
        pthread_mutex_unlock(&cons[conn_id]->con_lock);
    }

    
}

int wait4connect(uint32_t ip, uint16_t port)
{
    /* TODO: Implement the Three Way Handshake on the receiver part. This blocks
     * until a connection is established. */

    struct connection *con = (struct connection *)malloc(sizeof(struct connection));
    int conn_id = fdmax, ret;
    struct poli_tcp_data_hdr header;

    con->send_seg.clear();
    con->acked_seg.clear();
    con->recv_seg.clear();
    con->stored_seg.clear();
    

    /* Receive SYN on the connection socket. Create a new socket and bind it to
     * the chosen port. Send the data port number via SYN-ACK to the client */
    con->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    /* Bind the new socket */
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = ip;
    servaddr.sin_port = port;
    ret = bind(con->sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }

    /* Receive SYN segment */
    char response[MAX_SEGMENT_SIZE];
    memset(response, 0, sizeof(response));
    struct sockaddr_in client_addr;
    socklen_t clen = sizeof(client_addr);
    do {
        ret = recvfrom(cons_fd, response, sizeof(response), 0, (struct sockaddr *)&client_addr,
                            &clen);
        if (ret < 0) {
            printf("error found!\n");
            exit(-1);
        }
        header = *(struct poli_tcp_data_hdr *)&response;
    } while (!(header.type & SYN) || mp_addrs[client_addr.sin_port]);
    mp_addrs[client_addr.sin_port] = 1;
    con->servaddr = client_addr;

    /* Update connection fields */
    con->max_buff_size = buffer_len;
    con->buff_size = buffer_len;
    con->conn_id = fdmax;
    con->last_read = 0;
    con->port = port;
    con->got_ack = 0;
    con->got_syn = 1;
    con->did_connect = 0;
    con->buff_size = buffer_len;
    con->last_ack = 0;

    /* Since we can have multiple connection, we want to know if data is available
       on the socket used by a given connection. We use POLL for this */
    data_fds[con->conn_id].fd = con->sockfd;    
    data_fds[con->conn_id].events = POLLIN;    
    
    /* This creates a timer and sets it to trigger every 1 sec. We use this
       to know if a timeout has happend on a connection */
    timer_fds[con->conn_id].fd = timerfd_create(CLOCK_REALTIME,  0);    
    timer_fds[con->conn_id].events = POLLIN;    
    struct itimerspec spec;     
    spec.it_value.tv_sec = 1;    
    spec.it_value.tv_nsec = 0;    
    spec.it_interval.tv_sec = 1;    
    spec.it_interval.tv_nsec = 0;    
    timerfd_settime(timer_fds[con->conn_id].fd, 0, &spec, NULL);    
    fdmax++;    

    pthread_mutex_init(&con->con_lock, NULL);
    cons.insert({con->conn_id, con});

    while (!cons[conn_id]->did_connect) {
        usleep(10);
    }

    DEBUG_PRINT("Connection established!");

    return con->conn_id;
}

void init_receiver(int recv_buffer_bytes)
{
    pthread_t thread1;
    int ret;
    mp_addrs.clear();
    buffer_len = recv_buffer_bytes;
    /* TODO: Create the connection socket and bind it to 8031 */

    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        printf("error found!\n");
        exit(-1);
    }
    cons_fd = sockfd;

    /* Useful socket option */
    int enable = 1;
    ret = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }
    
    /* Bind server socket */
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(8031);
    ret = bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }
    ret = pthread_create( &thread1, NULL, receiver_handler, NULL);
    assert(ret == 0);
}
