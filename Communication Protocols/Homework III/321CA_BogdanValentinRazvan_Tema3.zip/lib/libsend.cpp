#include <pthread.h>
#include <cstdlib>
#include <map>
#include <cstdint>
#include "lib.h"
#include "utils.h"
#include "protocol.h"
#include <cassert>
#include <poll.h>
#include <sys/timerfd.h>
#include <cstring>
#include <math.h>
#include <unistd.h>

using namespace std;

std::map<int, struct connection *> cons;

struct pollfd data_fds[MAX_CONNECTIONS];
/* Used for timers per connection */
struct pollfd timer_fds[MAX_CONNECTIONS];
int fdmax = 0, window_size = 0;
uint32_t server_ip;
struct sockaddr_in server_addrs;
string message_string;
char data[MAX_SEGMENT_SIZE], message[MAX_SEGMENT_SIZE];
struct poli_tcp_data_hdr header_data, syn_message;
struct poli_tcp_ctrl_hdr header_ctrl;

void create_new_data_segment(int conn_id, char *buff, int len)
{
    char message[MAX_SEGMENT_SIZE];
    memset(message, 0, sizeof(message));

    struct poli_tcp_data_hdr data_message;
    data_message.protocol_id = POLI_PROTOCOL_ID;
    data_message.conn_id = cons[conn_id]->conn_id;
    data_message.type = DATE;
    data_message.seq_num = cons[conn_id]->seq_num++;
    data_message.len = len;
    char payload[MAX_DATA_SIZE];
    memset(payload, 0, sizeof(payload));
    memcpy(payload, buff, len);
    memcpy(message, &data_message, sizeof(data_message));
    memcpy(message + sizeof(data_message), payload, sizeof(payload));
    message_string = convert_char_to_string(message_string, message, MAX_SEGMENT_SIZE);

    cons[conn_id]->send_seg.push_back(message_string);

}

int send_data(int conn_id, char *buffer, int len)
{
    int size = 0;

    pthread_mutex_lock(&cons[conn_id]->con_lock);
    /* We will write code here as to not have sync problems with sender_handler */

    /* Divide buffer in segments and add them to the limited buffer */
    int new_segments = (len + MAX_DATA_SIZE - 1) / MAX_DATA_SIZE;
    for (int i = 0; i < new_segments; ++i) {
        create_new_data_segment(conn_id, buffer + size, min(len, MAX_DATA_SIZE));
        size += min(len, MAX_DATA_SIZE);
        len -= MAX_DATA_SIZE;
    }

    pthread_mutex_unlock(&cons[conn_id]->con_lock);

    return size;
}

void send_syn_segment(struct connection *con)
{
    memset(&syn_message, 0, sizeof(syn_message));
    syn_message.protocol_id = POLI_PROTOCOL_ID;
    syn_message.conn_id = 0;
    syn_message.type = SYN;
    syn_message.seq_num = 0;
    syn_message.len = 0;
    char data[MAX_DATA_SIZE];
    memset(data, 0, sizeof(data));
    char response[MAX_DATA_SIZE];
    memset(response, 0, sizeof(response));
    memset(message, 0, sizeof(message));
    memcpy(message, &syn_message, sizeof(syn_message));
    memcpy(message + sizeof(syn_message), data, sizeof(data));

    sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(8031);
    server_addr.sin_addr.s_addr = server_ip;

    int ret;
    ret = sendto(con->sockfd, message, sizeof(message), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }
}
void send_ack_segment(struct connection *con)
{
    int ret;
    memset(data, 0, sizeof(data));
    memset(&syn_message, 0, sizeof(syn_message));
    syn_message.protocol_id = POLI_PROTOCOL_ID;
    syn_message.conn_id = 0;
    syn_message.type = ACK;
    syn_message.seq_num = 1;
    syn_message.len = 0;

    /* Send ACK message */
    memset(data, 0, sizeof(data));
    memset(message, 0, sizeof(message));
    memcpy(message, &syn_message, sizeof(syn_message));
    memcpy(message + sizeof(syn_message), data, sizeof(data));

    ret = sendto(con->sockfd, message, sizeof(message), 0, (sockaddr *)&con->servaddr, sizeof(con->servaddr));
    if (ret < 0) {
        printf("error found!\n");
        exit(-1);
    }
}

void update_details(struct connection *con, char *response)
{
    uint32_t nr = (atoi(response + sizeof(poli_tcp_ctrl_hdr)));
    con->conn_id = 0;
    con->seq_num = 1;
    con->got_syn_ack = 0;
    con->recv_buff_size = MAX_SEGMENT_SIZE;
    con->max_window_seq = window_size;
    con->servaddr = server_addrs;
}


int try_three_way_handshake(struct connection *con)
{
    if (!con->got_syn_ack) {
        send_syn_segment(con);
        return 0;
    } else {
        con->did_connect = 1;
        return 1;
    }
}

int check_three_way_handshake(struct connection *con, struct poli_tcp_ctrl_hdr header_data, char *response)
{
    if (header_data.type == (SYN | ACK)) {
        if (!con->got_syn_ack) {
            update_details(con, response);
            send_ack_segment(con);
            con->did_connect = 1;
            return 1;
        }
        con->got_syn_ack = 1;
        send_ack_segment(con);
        return 1;
    }
    return 0;
}


void *sender_handler(void *arg)
{
    int res = 0, ret = 0, try_con;
    char buf[MAX_SEGMENT_SIZE], segment[MAX_SEGMENT_SIZE];

    while (1) {

        if (cons.size() == 0) {
            continue;
        }
        int conn_id = -1;
        do {
            res = recv_message_or_timeout(buf, MAX_SEGMENT_SIZE, &conn_id);
        } while(res == -14);

        pthread_mutex_lock(&cons[conn_id]->con_lock);

        /* Handle segment received from the receiver. We use this between locks
        as to not have synchronization issues with the send_data calls which are
        on the main thread */
        header_ctrl = *(struct poli_tcp_ctrl_hdr *)buf;
        int cnt = 0;
        switch (res) {
            /* Timer went off, resend the window for unACKED segments */
            case -1:
                try_con = try_three_way_handshake(cons[conn_id]);
                if (try_con) {
                    goto end;
                }
                if (!cons[conn_id]->recv_buff_size) {
                    cons[conn_id]->recv_buff_size = MAX_SEGMENT_SIZE;
                    continue;
                }
                for (size_t i = 0; i < min((size_t)cons[conn_id]->max_window_seq, cons[conn_id]->send_seg.size()); ++i) {
                    char segment[MAX_DATA_SIZE];
                    convert_string_to_char(cons[conn_id]->send_seg[i], segment, MAX_SEGMENT_SIZE);
                    header_data = *(struct poli_tcp_data_hdr *)segment;
                    if (cons[conn_id]->acked_seg[header_data.seq_num]) {
                        continue;
                    }

                    ++cnt;
                    ret = sendto(cons[conn_id]->sockfd, segment,
                            MAX_SEGMENT_SIZE, 0, (struct sockaddr *)&cons[conn_id]->servaddr,
                            sizeof(cons[conn_id]->servaddr));
                    if (ret < 0) {
                        printf("error found!\n");
                        exit(-1);
                    }
                }
                break;

            default:
                try_con = check_three_way_handshake(cons[conn_id], header_ctrl, segment);
                if (try_con) {
                    goto end;
                }
            /* Received a new ACK, resize the window if it is for next in order segment */
                cons[conn_id]->acked_seg[header_ctrl.ack_num] = 1;
                if (!cons[conn_id]->send_seg.size()) {
                    break;
                }
                cons[conn_id]->recv_buff_size = header_ctrl.recv_window;
                convert_string_to_char(cons[conn_id]->send_seg[0], segment, MAX_SEGMENT_SIZE);
                header_data = *(struct poli_tcp_data_hdr *)segment;
                while (cons[conn_id]->acked_seg[header_data.seq_num]) {
                    if (cons[conn_id]->send_seg.size() > 1) {
                        convert_string_to_char(cons[conn_id]->send_seg[1], segment, MAX_SEGMENT_SIZE);
                        header_data = *(struct poli_tcp_data_hdr *)segment;
                        cons[conn_id]->send_seg.erase(cons[conn_id]->send_seg.begin());
                    } else {
                        cons[conn_id]->send_seg.erase(cons[conn_id]->send_seg.begin());
                        break;
                    }
                }
                break;
        }
end:
        pthread_mutex_unlock(&cons[conn_id]->con_lock);
    }
}

int setup_connection(uint32_t ip, uint16_t port)
{
    /* Implement the sender part of the Three Way Handshake. Blocks
    until the connection is established */

    struct connection *con = (struct connection *)malloc(sizeof(struct connection));
    con->send_seg.clear();
    con->acked_seg.clear();
    con->recv_seg.clear();
    con->stored_seg.clear();

    int conn_id = 0;
    con->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    server_ip = ip;

    con->conn_id = 0;
    con->seq_num = 1;
    con->got_syn_ack = 0;
    con->did_connect = 0;
    con->recv_buff_size = MAX_SEGMENT_SIZE;
    con->max_window_seq = window_size;

    /* Since we can have multiple connection, we want to know if data is available
       on the socket used by a given connection. We use POLL for this */
    data_fds[fdmax].fd = con->sockfd;    
    data_fds[fdmax].events = POLLIN;    
    
    /* This creates a timer and sets it to trigger every 1 sec. We use this
       to know if a timeout has happend on our connection */
    timer_fds[fdmax].fd = timerfd_create(CLOCK_REALTIME,  0);    
    timer_fds[fdmax].events = POLLIN;
    struct itimerspec spec;     
    spec.it_value.tv_sec = 0;    
    spec.it_value.tv_nsec = 10000000;    
    spec.it_interval.tv_sec = 0;    
    spec.it_interval.tv_nsec = 10000000;
    timerfd_settime(timer_fds[fdmax].fd, 0, &spec, NULL);    
    ++fdmax;


    pthread_mutex_init(&con->con_lock, NULL);
    cons.insert({conn_id, con});

    while (!cons[conn_id]->did_connect) {
        usleep(10);
    }

    DEBUG_PRINT("Connection established!");

    return 0;
}

void init_sender(int speed, int delay)
{
    pthread_t thread1;
    int ret;
    window_size = 20;
    /* Create a thread that will*/
    ret = pthread_create( &thread1, NULL, sender_handler, NULL);
    assert(ret == 0);
}
