#include <string>
#include <cstring>
#include "utils.h"

std::string convert_char_to_string(std::string sol, char *buf, int len)
{
    sol = "";
    for (int i = 0; i < len; ++i) {
        sol += buf[i];
    }
    return sol;
}

void convert_string_to_char(std::string str, char *buf, int len)
{
    memset(buf, 0, len);
    for (int i = 0; i < len; ++i) {
        buf[i] = str[i];
    }
}
