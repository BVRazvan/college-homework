#include "queue.h"
#include "lib.h"
#include "list.h"
#include "protocols.h"
#include "trie.h"

#include <arpa/inet.h>
#include <string.h>

#define RTABLE_LEN 150000
#define MACTABLE_LEN 105
#define ECHO_REQUEST 8
#define IPV4_PACKET 0x0800
#define ARP_PACKET 0x0806
#define HLEN 6
#define PLEN 4
#define OP_REQUEST htons(1)
#define OP_REPLY htons(2)

struct queued_packet {
	void *payload;
	uint16_t size;
};

struct cam_table {
	int interface;
	uint8_t mac[6];
};

uint8_t broadcast[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

/* Routing table */
struct route_table_entry *rtable, *aux;
int rtable_len;

/* Mac table */
struct arp_entry *arp_table;
int arp_table_len;

struct arp_entry *get_arp_entry(uint32_t given_ip) {
	/* Iterate through the MAC table and search for an entry
	 * that matches given_ip. */

	for (uint32_t i = 0; i < arp_table_len; ++i) {
		if (given_ip == arp_table[i].ip) {
			return arp_table + i;
		}
	}

	return NULL;
}

void set_arp_header(uint32_t interface, struct arp_header *arp_hdr, uint16_t htype,
					uint16_t ptype, uint8_t hlen, uint8_t plen, uint16_t op,
					uint8_t sha[], uint32_t spa, uint8_t tha[], uint32_t tpa)
{
	uint8_t tmp_1[MAX_PACKET_LEN], tmp_2[MAX_PACKET_LEN];
	
	memcpy(tmp_1, sha, sizeof(tmp_1));
	memcpy(tmp_2, tha, sizeof(tmp_2));

	arp_hdr->htype = htype;
	arp_hdr->ptype = ptype;
	arp_hdr->hlen = hlen;
	arp_hdr->plen = plen;
	arp_hdr->op = op;
	arp_hdr->spa = spa;
	arp_hdr->tpa = tpa;
	
	memcpy(arp_hdr->sha, tmp_1, sizeof(arp_hdr->sha));
	memcpy(arp_hdr->tha, tmp_2, sizeof(arp_hdr->tha));
}

void set_eth_header(struct ether_header *eth_hdr,
					uint8_t ether_shost[], uint8_t ether_dhost[], uint16_t ether_type)
{
	uint8_t tmp_1[MAX_PACKET_LEN], tmp_2[MAX_PACKET_LEN];
	
	memcpy(tmp_1, ether_shost, sizeof(tmp_1));
	memcpy(tmp_2, ether_dhost, sizeof(tmp_2));

	memcpy(eth_hdr->ether_shost, tmp_1, sizeof(eth_hdr->ether_shost));
	memcpy(eth_hdr->ether_dhost, tmp_2, sizeof(eth_hdr->ether_dhost));

	eth_hdr->ether_type = ether_type;
}

void send_icmp_reply(char *buf, uint8_t *rmac, uint32_t interface, uint8_t type, uint32_t old_cs)
{
	char ans[MAX_PACKET_LEN];
	memset(ans, 0, sizeof(ans));
	
	char *ip_ascii = get_interface_ip(interface);
	uint32_t ip_decimal = 0;
	uint32_t ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);

	struct iphdr *ip_hdr = (struct iphdr *)(buf + sizeof(struct ether_header));
	struct icmphdr * icmp_hdr = (struct icmphdr *) ((char *)ip_hdr + sizeof(struct iphdr));
	struct ether_header *new_eth_hdr = (struct ether_header *) ans;
	struct iphdr *new_ip_hdr = (struct iphdr *)(ans + sizeof(struct ether_header));
	struct icmphdr * new_icmp_hdr = (struct icmphdr *) ((char *)new_ip_hdr + sizeof(struct iphdr));

	memcpy(ans, buf, sizeof(struct ether_header));
	get_interface_mac(interface, rmac);

	set_eth_header(new_eth_hdr, rmac, new_eth_hdr->ether_shost, new_eth_hdr->ether_type);

	memcpy(new_ip_hdr, ip_hdr, sizeof(struct iphdr));

	ip_ascii = get_interface_ip(interface);
	ip_decimal = 0;
	ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);
	DIE(ret < 1, "inet_pton error!\n");

	new_ip_hdr->daddr = new_ip_hdr->saddr;
	new_ip_hdr->saddr = ip_decimal;
	new_ip_hdr->version = 4;
	new_ip_hdr->ttl = 255;
	new_ip_hdr->check = 0;
	new_ip_hdr->tos = 0;
	new_ip_hdr->protocol = 1;
	new_ip_hdr->frag_off = 0;
	new_ip_hdr->check = checksum((uint16_t *)new_ip_hdr, sizeof(struct iphdr));
	new_ip_hdr->tot_len = htons(sizeof(struct icmphdr) + 2 * sizeof(struct iphdr) + 8);
	new_icmp_hdr->type = type;
	new_icmp_hdr->code = 0;
	new_icmp_hdr->checksum = 0;

	++ip_hdr->ttl;	
	ip_hdr->check = htons(old_cs);

	memcpy((char *)new_icmp_hdr + sizeof(struct icmphdr), ip_hdr, sizeof(struct iphdr));
	memcpy((char *)new_icmp_hdr + sizeof(struct icmphdr) + sizeof(struct iphdr), icmp_hdr, 8);

	new_icmp_hdr->checksum = htons(checksum((uint16_t *)new_icmp_hdr, 36));

	send_to_link(interface, ans, sizeof(struct icmphdr) + 2 * sizeof(struct iphdr) +
				sizeof(struct ether_header) + 8);
}

void send_arp_request(char *buf, queue q, struct route_table_entry *next_hop, uint32_t len, uint16_t *queue_len, uint32_t interface)
{
	char arp_req[MAX_PACKET_LEN];
	memset(arp_req, 0, sizeof(arp_req));
	++(*queue_len);

	struct queued_packet enq_packet;
	enq_packet.payload = malloc(len * sizeof(*buf));
	memcpy(enq_packet.payload, buf, len);
	enq_packet.size = len;

	queue_enq(q, &enq_packet);

	struct ether_header *arp_req_eth_hdr = (struct ether_header *)(arp_req);
	
	get_interface_mac(next_hop->interface, arp_req_eth_hdr->ether_shost);

	set_eth_header(arp_req_eth_hdr, arp_req_eth_hdr->ether_shost, broadcast, htons(ARP_PACKET));

	struct arp_header *arp_req_arp_hdr = (struct arp_header *)(sizeof(struct ether_header) + arp_req);
	char *ip_ascii = get_interface_ip(next_hop->interface);

	uint32_t ip_decimal = 0;
	uint32_t ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);
	DIE(ret < 1, "inet_pton error!\n");

	set_arp_header(interface, arp_req_arp_hdr, htons(1), htons(IPV4_PACKET),
					HLEN, 4, OP_REQUEST, arp_req_eth_hdr->ether_shost,
					ip_decimal, arp_req_arp_hdr->tha, next_hop->next_hop);

	send_to_link(next_hop->interface, arp_req, sizeof(struct ether_header) + sizeof(struct arp_header));
}

int main(int argc, char *argv[])
{
	// Do not modify this line
	init(argc - 2, argv + 2);

	char buf[MAX_PACKET_LEN];
	struct trie *trie_route;
	static uint16_t queue_len = 0;
	queue q = NULL;
	q = queue_create();

	trie_route = malloc(sizeof(struct trie));
	DIE(trie_route == NULL, "memory");

	trie_route->root = malloc(sizeof(*trie_route->root));
	DIE(trie_route->root == NULL, "memory");

	trie_route->root->data = NULL;
	trie_route->root->left = NULL;
	trie_route->root->right = NULL;
	trie_route->root->rentry = NULL;

	/* Code to allocate the MAC and route tables */
	rtable = malloc(sizeof(struct route_table_entry) * RTABLE_LEN);
	aux = malloc(sizeof(struct route_table_entry) * RTABLE_LEN);
	arp_table = malloc(sizeof(struct  arp_entry) * MACTABLE_LEN);
	/* DIE is a macro for sanity checks */
	DIE(rtable == NULL, "memory");
	DIE(aux == NULL, "memory");
	DIE(arp_table == NULL, "memory");

	/* Read the static routing table and the MAC table */
	rtable_len = read_rtable(argv[1], rtable);

	for (int i = 0; i < rtable_len; ++i) {
		add(trie_route->root, rtable + i);
	}

	while (1) {
		int interface;
		size_t len;

		interface = recv_from_any_link(buf, &len);
		DIE(interface < 0, "recv_from_any_links");

		struct ether_header *eth_hdr = (struct ether_header *) buf;
		/* Note that packets received are in network order,
		any header field which has more than 1 byte will need to be conerted to
		host order. For example, ntohs(eth_hdr->ether_type). The oposite is needed when
		sending a packet on the link, */

		uint16_t ether_type = ntohs(eth_hdr->ether_type);

		uint8_t rmac[6];
		memset(rmac, 0, sizeof(rmac));
		get_interface_mac(interface, rmac);

		struct iphdr *ip_hdr = (struct iphdr *)(buf + sizeof(struct ether_header));
		struct arp_header *arp_hdr = (struct arp_header *)(buf + sizeof(struct ether_header));
		struct icmphdr * icmp_hdr = (struct icmphdr *) ((char *)ip_hdr + sizeof(struct iphdr));
		
		char *ip_ascii = get_interface_ip(interface);
		uint32_t ip_decimal = 0;
		uint32_t ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);
		DIE(ret < 1, "inet_pton error!\n");

		if (memcmp(broadcast, eth_hdr->ether_dhost, sizeof(eth_hdr->ether_dhost))
			&& memcmp(rmac, eth_hdr->ether_dhost, sizeof(eth_hdr->ether_dhost))) {
			continue;
		}
		if (ether_type != IPV4_PACKET && ether_type != ARP_PACKET) {
			continue;
		}
		if (ether_type == ARP_PACKET) {
			goto ARP_LABEL;
		} else {
			goto IP_LABEL;
		}

IP_LABEL: ;

		/* Check the ip_hdr integrity using ip_checksum((uint16_t *)ip_hdr, sizeof(struct iphdr)) */
		uint16_t old_cs = ntohs(ip_hdr->check);
		uint16_t new_cs = 0;
		
		ip_hdr->check = 0;
		new_cs = checksum((uint16_t *)ip_hdr, sizeof(struct iphdr));
		if (new_cs != old_cs) {
			continue;
		}
		
		/*  Check TTL >= 1. Update TLL. Update checksum  */
		--ip_hdr->ttl;
		if (ip_hdr->ttl <= 0) {
			send_icmp_reply(buf, rmac, interface, 11, old_cs);
			continue;
		}

		new_cs = checksum((uint16_t *)ip_hdr, sizeof(struct iphdr));
		ip_hdr->check = htons(new_cs);

		/* Call search to find the most specific route, continue; (drop) if null */
		struct route_table_entry* next_hop = search(trie_route->root, ip_hdr->daddr);
	
		if (!next_hop) {
			send_icmp_reply(buf, rmac, interface, 3, old_cs);
			continue;
		}

		/* Update the ethernet addresses. Use get_mac_entry to find the destination MAC
		 * address. Use get_interface_mac(m.interface, uint8_t *mac) to
		 * find the mac address of our interface. */

		if (icmp_hdr->type == ECHO_REQUEST && ip_decimal == ip_hdr->daddr) {
			struct route_table_entry* next_hop = search(trie_route->root, ip_hdr->saddr);
			struct arp_entry* arp_entry = get_arp_entry(next_hop->next_hop);

			get_interface_mac(next_hop->interface, rmac);

			ip_ascii = get_interface_ip(next_hop->interface);
			ip_decimal = 0;
			ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);

			set_eth_header(eth_hdr, rmac, arp_entry->mac, eth_hdr->ether_type);

			ip_hdr->daddr = ip_hdr->saddr;
			ip_hdr->saddr = ip_decimal;
			icmp_hdr->type = 0;
			icmp_hdr->checksum = 0;
			icmp_hdr->checksum = htons(checksum((uint16_t *)icmp_hdr, len));

			send_to_link(next_hop->interface, buf, len);
			continue;
		}
		struct arp_entry* arp_entry = get_arp_entry(next_hop->next_hop);

		if (!arp_entry) {
			send_arp_request(buf, q, next_hop, len, &queue_len, interface);

			continue;
		}
		memcpy(eth_hdr->ether_dhost, arp_entry->mac, sizeof(eth_hdr->ether_dhost));
		get_interface_mac(next_hop->interface, eth_hdr->ether_shost);

		send_to_link(next_hop->interface, buf, len);

		continue;

ARP_LABEL: ;

		if (arp_hdr->op == OP_REPLY) {
			goto ARP_REPLY;
		} else if (arp_hdr->op == OP_REQUEST) {
			goto ARP_REQUEST;
		} else {
			continue;
		}

ARP_REQUEST: ;

		ip_decimal = 0;
		ret = inet_pton(AF_INET, ip_ascii, &ip_decimal);
		DIE(ret < 1, "inet_pton error!\n");

		arp_entry = get_arp_entry(arp_hdr->tpa);
	
		if (!arp_entry) {
			
			set_eth_header(eth_hdr, rmac, eth_hdr->ether_shost, htons(ARP_PACKET));
			get_interface_mac(interface, eth_hdr->ether_shost);
			set_arp_header(interface, arp_hdr, htons(1), htons(IPV4_PACKET), HLEN,
							4, OP_REPLY, eth_hdr->ether_shost, arp_hdr->tpa,
							eth_hdr->ether_dhost, arp_hdr->spa);

			send_to_link(interface, buf, len);

			continue;

		} else {
			char arp_rep[MAX_PACKET_LEN];
			memset(arp_rep, 0, sizeof(arp_rep));
			memcpy(arp_rep, buf, len);

			struct ether_header *arp_rep_eth_hdr = (struct ether_header *)(arp_rep);
			struct arp_header *arp_rep_arp_hdr = (struct arp_header *)(sizeof(struct ether_header) + arp_rep);

			next_hop = search(trie_route->root, arp_hdr->spa);

			set_eth_header(arp_rep_eth_hdr, arp_entry->mac, arp_rep_eth_hdr->ether_shost, htons(ARP_PACKET));
			set_arp_header(interface, arp_rep_arp_hdr, htons(1), htons(IPV4_PACKET),
							HLEN, 4, OP_REPLY, rmac, ip_decimal,
							arp_rep_eth_hdr->ether_dhost, arp_hdr->spa);

			send_to_link(next_hop->interface, arp_rep, len);
		}
		continue;

ARP_REPLY: ;

		struct arp_entry new_entry;

		memset(new_entry.mac, 0, sizeof(new_entry.mac));
		new_entry.ip = arp_hdr->spa;
		memcpy(new_entry.mac, eth_hdr->ether_shost, sizeof(new_entry.mac));
		arp_table[arp_table_len++] = new_entry;

		uint32_t new_queue_len = 0;
		char old_packet[MAX_PACKET_LEN];

		for (uint32_t i = 0; i < queue_len; ++i) {
			struct queued_packet *p = (struct queued_packet *) queue_deq(q);

			memcpy(old_packet, p->payload, p->size);
			struct ether_header *old_eth_hdr = (struct ether_header *) old_packet;
			struct iphdr *old_ip_hdr = (struct iphdr *)(sizeof(struct ether_header) + old_packet);

			next_hop = search(trie_route->root, old_ip_hdr->daddr);
			arp_entry = get_arp_entry(next_hop->next_hop);

			if (arp_entry) {
				memcpy(old_eth_hdr->ether_dhost, arp_entry->mac, sizeof(eth_hdr->ether_dhost));
				get_interface_mac(next_hop->interface, old_eth_hdr->ether_shost);

				send_to_link(next_hop->interface, old_packet, p->size);
			} else {
				++new_queue_len;
				queue_enq(q, p);
			}
		}
		queue_len = new_queue_len;
	}

	return 0;
}

