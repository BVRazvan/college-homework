#include "trie.h"

uint32_t better(struct route_table_entry *cand, struct route_table_entry *sol)
{
    if (!sol || ntohl(cand->mask) > ntohl(sol->mask)) {
        return 1;
    }

    return 0;
}

void add(struct node *root, struct route_table_entry *entry)
{
    struct node *parc = root;
    uint32_t ip = ntohl(entry->prefix);

    uint32_t bitmask = ~(uint32_t)((1UL << 31) - 1);

    while (bitmask) {
        uint32_t byte = (ip & bitmask);

        if (parc->left && !byte) {
            parc = parc->left;

            if (ntohl(entry->mask) > ntohl(parc->rentry->mask)) {
                parc->rentry = entry;
            }
        } else if (parc->right && byte) {
            parc = parc->right;

            if (ntohl(entry->mask) > ntohl(parc->rentry->mask)) {
                parc->rentry = entry;
            }
        } else {
            if (byte) {
                parc->right = malloc(sizeof(*parc->right));
                DIE(!parc->right, "malloc() failed!\n");

                parc->right->data = malloc(sizeof(uint32_t));
                parc->right->rentry = entry;
                memcpy(parc->right->data, &byte, sizeof(*(uint32_t *)parc->right->data));
                parc->right->left = NULL;
                parc->right->right = NULL;
                parc = parc->right;
            } else {
                parc->left = malloc(sizeof(*parc->left));
                DIE(!parc->left, "malloc() failed!\n");

                parc->left->data = malloc(sizeof(uint32_t));
                parc->left->rentry = entry;
                memcpy(parc->left->data, &byte, sizeof(*(uint32_t *)parc->left->data));
                parc->left->left = NULL;
                parc->left->right = NULL;
                parc = parc->left;
            }
        }
        bitmask >>= 1;
    }
}

struct route_table_entry *search(struct node *root, uint32_t ip)
{
    struct node *parc = root;
    struct route_table_entry *sol = NULL;
    uint32_t init_ip = ip;
    uint32_t bitmask = ~(uint32_t)((1UL << 31) - 1);
    ip = ntohl(ip);

    while (bitmask) {
        uint32_t byte = (ip & bitmask);

        if (parc->left && !byte) {
            parc = parc->left;

            if ((init_ip & parc->rentry->mask) == parc->rentry->prefix && better(parc->rentry, sol)) {
                sol = parc->rentry;
            }
        } else if (parc->right && byte) {
            parc = parc->right;

            if ((init_ip & parc->rentry->mask) == parc->rentry->prefix && better(parc->rentry, sol)) {
                sol = parc->rentry;
            }
        } else {
            return sol;
        }
        
        bitmask >>= 1;
    }

    return sol;
}
