#ifndef TRIE_H
#define TRIE_H

#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <string.h>

#include "lib.h"
#include "queue.h"
#include "list.h"
#include "protocols.h"

struct node {
    void *data;
    struct route_table_entry *rentry;
    struct node *left;
    struct node *right;
};

struct trie {
    struct node *root;
};

void add(struct node *root, struct route_table_entry *entry);

struct route_table_entry *search(struct node *root, uint32_t ip);

uint32_t better(struct route_table_entry *cand, struct route_table_entry *sol);

#endif