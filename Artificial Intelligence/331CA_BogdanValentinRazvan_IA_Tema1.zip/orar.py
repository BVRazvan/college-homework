from ast import literal_eval
import copy
from heapq import heappop, heappush
from math import ceil
import random
import sys
import time

from check_constraints import CAPACITATE, check_mandatory_constraints, check_optional_constraints, parse_interval
from utils import CONSTRANGERI, INTERVALE, MATERII, NOF_COURSES_LIMIT, PROFESORI, SALI, ZILE, pretty_print_timetable, read_yaml_file

class Discovery_State():
    def __init__(self, assigned_students_to_courses, assigned_profs_to_courses_limit, assigned_profs_to_courses_spot, assigned_rooms_to_courses):
        self.timetable = {}
        for day in timetable_specs[ZILE]:
            self.timetable[day] = {}
            for interval in timetable_specs[INTERVALE]:
                intervals = interval.strip('()')
                intervals = intervals.split(',')
                start, final = int(intervals[0].strip()), int(intervals[1].strip())

                self.timetable[day][(start, final)] = {}

                for room in timetable_specs[SALI]:
                    self.timetable[day][(start, final)][room] = {}

        self.assigned_students_to_courses = assigned_students_to_courses
        self.assigned_profs_to_courses_limit = assigned_profs_to_courses_limit
        self.assigned_profs_to_courses_spot = assigned_profs_to_courses_spot
        self.assigned_rooms_to_courses = assigned_rooms_to_courses
        self.nof_assigned_students = 0
        self.assigned_day = {day : 0 for day in timetable_specs[ZILE]}
        self.nof_assigned_rooms = {room : 0 for room in timetable_specs[SALI]}
        self.assigned_interval = {interval : 0 for interval in timetable_specs[INTERVALE]}
        self.soft_constraints = 0
    
    def generate_next_states(self, suitable_intervals):
        next_states = []

        timetable_specs = suitable_intervals.timetable_specs

        for day in timetable_specs[ZILE]:
            for interval in timetable_specs[INTERVALE]:
                for room in timetable_specs[SALI]:
                    for prof in timetable_specs[PROFESORI]:
                        if self.assigned_profs_to_courses_limit[prof] >= NOF_COURSES_LIMIT:
                            continue
                        if prof in self.assigned_profs_to_courses_spot.keys() and (day, interval) in self.assigned_profs_to_courses_spot[prof]:
                            continue
                        for course in timetable_specs[MATERII]:
                            if self.assigned_students_to_courses[course] >= timetable_specs[MATERII][course]:
                                continue
                            if course not in timetable_specs[PROFESORI][prof][MATERII]:
                                continue
                            if course not in timetable_specs[SALI][room][MATERII] or ((room, day, interval) in self.assigned_rooms_to_courses.keys() and self.assigned_rooms_to_courses[(room, day, interval)] is True):
                                continue

                            next_states.append((day, interval, room, prof, course))

                            if len(next_states) > 2000:
                                random.shuffle(next_states)
                                return next_states

        random.shuffle(next_states)
        
        return next_states
    
    def update_state(self, day, interval, room, prof, course, suitable_intervals):
        timetable_specs = suitable_intervals.timetable_specs
        self.assigned_students_to_courses[course] += min(timetable_specs[MATERII][course] - self.assigned_students_to_courses[course], timetable_specs[SALI][room][CAPACITATE])
        self.assigned_profs_to_courses_limit[prof] += 1

        if prof not in self.assigned_profs_to_courses_spot:
            self.assigned_profs_to_courses_spot[prof] = []

        self.assigned_profs_to_courses_spot[prof].append((day, interval))

        self.assigned_rooms_to_courses[(room, day, interval)] = True
        self.nof_assigned_students += min(timetable_specs[MATERII][course] - self.assigned_students_to_courses[course], timetable_specs[SALI][room][CAPACITATE])

        intervals = interval.strip('()')
        intervals = intervals.split(',')
        start, final = int(intervals[0].strip()), int(intervals[1].strip())

        if day not in self.timetable:
            self.timetable[day] = {}
        if (start, final) not in self.timetable[day]:
            self.timetable[day][(start, final)] = {}
        if room not in self.timetable[day][(start, final)]:
            self.timetable[day][(start, final)][room] = {}
        
        self.timetable[day][(start, final)][room] = (prof, course)

        self.nof_assigned_rooms[room] += 1

        self.assigned_day[day] += 1

        self.assigned_interval[interval] += 1

        self.soft_constraints += self.find_soft_constraints(prof, day, interval, suitable_intervals)

    def find_soft_constraints(self, prof, day, interval, suitable_intervals):
        found = 0
        if (prof, day) not in suitable_intervals.suitable_intervals_profs.keys():
            found += 1
        
        if (prof, literal_eval(interval)) not in suitable_intervals.suitable_intervals_profs.keys():
            found += 1

        return found

    def is_final(self, timetable_specs):
        for course in timetable_specs[MATERII]:
            if self.assigned_students_to_courses[course] < timetable_specs[MATERII][course]:
                    return False

        return True
    
    def calculate_g_function(self, day, interval, prof, suitable_intervals):
        if day is None:
            return 0
         
        return self.find_soft_constraints(prof, day, interval, suitable_intervals)
        
    def calculate_h_function(self, timetable_specs, suitable_intervals):
        slots_to_add = sum(((timetable_specs[MATERII][course] - self.assigned_students_to_courses[course]) / suitable_intervals.biggest_capacity) for course in timetable_specs[MATERII])

        if slots_to_add == 0:
            return 0
        
        cost_prof = 0
        for prof in timetable_specs[PROFESORI]:
            if self.assigned_profs_to_courses_limit[prof] < NOF_COURSES_LIMIT:
                cost_prof += (1 - suitable_intervals.teaching_prof_weight[prof] / suitable_intervals.teaching_prof_weight_max) * (NOF_COURSES_LIMIT - self.assigned_profs_to_courses_limit[prof])

        cost_course = 0
        for course in timetable_specs[MATERII]:
            if self.assigned_students_to_courses[course] < timetable_specs[MATERII][course]:
                cost_course += (1 - suitable_intervals.teached_course_weight[course] / suitable_intervals.teached_course_weight_max) * (timetable_specs[MATERII][course] - self.assigned_students_to_courses[course]) / suitable_intervals.biggest_capacity
        
        cost_room = 0
        for room in timetable_specs[SALI]:
            if self.nof_assigned_rooms[room] < len(timetable_specs[ZILE]) * len(timetable_specs[INTERVALE]):
                cost_room += (1 - suitable_intervals.used_room_weight[room] / suitable_intervals.used_room_weight_max) * (len(timetable_specs[ZILE]) * len(timetable_specs[INTERVALE]) - self.nof_assigned_rooms[room])

        cost = cost_course + cost_prof + cost_room  + slots_to_add
            
        return cost
    
    def can_append_spot(self, day, interval, room, prof, course):
        if self.assigned_profs_to_courses_limit[prof] == NOF_COURSES_LIMIT:
            return False
        if prof in self.assigned_profs_to_courses_spot.keys() and (day, interval) in self.assigned_profs_to_courses_spot[prof]:
            return False
        if self.assigned_students_to_courses[course] >= timetable_specs[MATERII][course]:
            return False
        if course not in timetable_specs[PROFESORI][prof][MATERII]:
            return False
        if course not in timetable_specs[SALI][room][MATERII] or ((room, day, interval) in self.assigned_rooms_to_courses.keys() and self.assigned_rooms_to_courses[(room, day, interval)] is True):
            return False
        
        return True

    def generate_timetable(self, suitable_intervals):
        while self.nof_assigned_students < suitable_intervals.total_students_to_assign / 2:
            day, (start, end), room, prof, course = random.choice(suitable_intervals.suitable_intervals)

            if self.can_append_spot(day, f'({start}, {end})', room, prof, course):
                self.update_state(day, f'({start}, {end})', room, prof, course, suitable_intervals)

    def conflicts(self):
        return self.soft_constraints
    
    def __lt__(self, other):
        return random.randrange(2)

class Suitable_Intervals_Singleton():
    def __init__(self, timetable_specs):
        self.biggest_capacity = max([timetable_specs[SALI][sala][CAPACITATE] for sala in timetable_specs[SALI]])
        self.smallest_capacity = min([timetable_specs[SALI][sala][CAPACITATE] for sala in timetable_specs[SALI]])
        self.total_students_to_assign = sum([timetable_specs[MATERII][course] for course in timetable_specs[MATERII]])
        self.timetable_specs = timetable_specs
        self.suitable_intervals = []
        self.suitable_intervals_profs = {}
        self.teached_course = {course : 0 for course in timetable_specs[MATERII]}
        self.teaching_prof = {prof : 0 for prof in timetable_specs[PROFESORI]}
        self.teached_course_weight = {}
        self.teached_course_weight_max = 0
        self.teaching_prof_weight = {}
        self.teaching_prof_weight_max = 0
        self.used_room_weight = {}
        self.used_room_weight_max = 0
        self.most_rooms = max(timetable_specs[MATERII][course] for course in timetable_specs[MATERII]) / self.biggest_capacity

        self.precalculate_values()

    def precalculate_values(self):
        for prof in self.timetable_specs[PROFESORI]:
            for course in self.timetable_specs[PROFESORI][prof][MATERII]:
                self.teached_course[course] += 1
                self.teaching_prof[prof] += 1
        
        total_courses = sum(len(timetable_specs[PROFESORI][prof][MATERII]) for prof in timetable_specs[PROFESORI])
        for course in self.timetable_specs[MATERII]:
            self.teached_course_weight[course] = self.teached_course[course] / total_courses

        self.teached_course_weight_max = max(self.teached_course_weight[course] for course in self.timetable_specs[MATERII])
    
        for prof in self.timetable_specs[PROFESORI]:
            self.teaching_prof_weight[prof] = len(self.timetable_specs[PROFESORI][prof][MATERII]) / total_courses

        self.teaching_prof_weight_max = max(self.teaching_prof_weight[prof] for prof in self.timetable_specs[PROFESORI])

        total_rooms_courses = sum(len(timetable_specs[SALI][room][MATERII]) for room in timetable_specs[SALI])
        for room in self.timetable_specs[SALI]:
            self.used_room_weight[room] = len(self.timetable_specs[SALI][room][MATERII]) / total_rooms_courses

        self.used_room_weight_max = max(self.used_room_weight[room] for room in self.timetable_specs[SALI])

        for prof in self.timetable_specs[PROFESORI]:
            for day in timetable_specs[PROFESORI][prof][CONSTRANGERI]:

                if day in timetable_specs[ZILE]:
                    for interval in timetable_specs[PROFESORI][prof][CONSTRANGERI]:

                        if '-' in interval and interval[0] != '!':
                            interval = parse_interval(interval)
                            start, end = interval

                            if start != end - 2:
                                intervals = [(i, i + 2) for i in range(start, end, 2)]
                            else:
                                intervals = [(start, end)]

                            for interval in intervals:

                                for course in self.timetable_specs[MATERII]:
                                    if course not in self.timetable_specs[PROFESORI][prof][MATERII]:
                                        continue

                                    for room in self.timetable_specs[SALI]:
                                        if course not in self.timetable_specs[SALI][room][MATERII]:
                                            continue

                                        self.suitable_intervals.append((day, interval, room, prof, course))
                                        self.suitable_intervals_profs[(prof, day)] = True
                                        self.suitable_intervals_profs[(prof, interval)] = True

def astar(start, timetable_specs, suitable_intervals):
    frontier = []
    heappush(frontier, (start.calculate_g_function(None, None, None, suitable_intervals) + start.calculate_h_function(timetable_specs, suitable_intervals), start))

    discovered = {str(start.timetable): start.calculate_g_function(None, None, None, suitable_intervals)}
    
    generated_states = 0

    while frontier:
        cost_f, state = heappop(frontier)
        cost_g = discovered[str(state.timetable)]

        if state.is_final(timetable_specs):
            return state, generated_states
        
        new_states = state.generate_next_states(suitable_intervals)

        generated_states += len(new_states)

        for (day, interval, room, prof, course) in new_states:
            new_state = copy.deepcopy(state)
            new_state.update_state(day, interval, room, prof, course, suitable_intervals)

            (cost_g_new_state, cost_h_new_state) = (cost_g + new_state.calculate_g_function(day, interval, prof, suitable_intervals), new_state.calculate_h_function(timetable_specs, suitable_intervals))

            str_dict = str(new_state.timetable)
            if str_dict not in discovered.keys():
                discovered[str_dict] = cost_g_new_state
                heappush(frontier, (cost_g_new_state + cost_h_new_state, new_state))

def hill_climbing(state, max_iters, suitable_intervals, max_constraints):
    iters, states = 0, 0
    
    while iters < max_iters:
        iters += 1
        
        found_spot = False

        next_states = state.generate_next_states(suitable_intervals)

        states += len(next_states)

        for (day, interval, room, prof, course) in next_states:
            states += 1

            if state.find_soft_constraints(prof, day, interval, suitable_intervals) > 0:
                continue
            else:
                state.update_state(day, interval, room, prof, course, suitable_intervals)
                found_spot = True
                break

        if found_spot is False and len(next_states) > 0 and state.soft_constraints + state.find_soft_constraints(next_states[0][3], next_states[0][0], next_states[0][1], suitable_intervals) <= max_constraints:
            state.update_state(next_states[0][0], next_states[0][1], next_states[0][2], next_states[0][3], next_states[0][4], suitable_intervals)
        elif found_spot is False:
            break
                
    return state.is_final(suitable_intervals.timetable_specs), iters, states, state

def random_restart_hill_climbing(initial, max_restarts, run_max_iters, suitable_intervals, max_constraints):
    is_final = False
    total_iters, total_states = 0, 0
    
    initial.generate_timetable(suitable_intervals)

    while max_restarts > 0:
        is_final, iters, states, state = hill_climbing(initial, run_max_iters, suitable_intervals, max_constraints)

        total_iters += iters
        total_states += states

        if is_final:
            return is_final, total_iters, total_states, state
        else:
            initial = Discovery_State({subject : 0 for subject in timetable_specs[MATERII]}, {prof : 0 for prof in timetable_specs[PROFESORI]}, dict(), dict())
            initial.generate_timetable(suitable_intervals)

            max_restarts -= 1
        
    return is_final, total_iters, total_states, state

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print ('Provide 2 parameters: <algorithm> <input_file>')
        sys.exit()

    if sys.argv[1] not in ("astar", "hc"):
        print ('Algorithm should be one of [astar, hc]')
        sys.exit()
    
    filename = f'inputs/{sys.argv[2]}.yaml'

    timetable_specs = read_yaml_file(filename)
    suitable_intervals = Suitable_Intervals_Singleton(timetable_specs)
    start = Discovery_State({subject : 0 for subject in timetable_specs[MATERII]}, {prof : 0 for prof in timetable_specs[PROFESORI]}, dict(), dict())

    if sys.argv[1] == "astar":
        result, generated_states = astar(start, timetable_specs, suitable_intervals)

        print (pretty_print_timetable(result.timetable, filename))
    elif sys.argv[1] == "hc":
        for i in range(0, ceil(suitable_intervals.total_students_to_assign / suitable_intervals.smallest_capacity)):
            is_final, total_iters, total_states, state = random_restart_hill_climbing(start, 1000, 1000, suitable_intervals, i)
            
            if is_final:
                print (pretty_print_timetable(state.timetable, filename))
                break