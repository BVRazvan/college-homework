#include <bits/stdc++.h>
#include <time.h> 

#pragma GCC optimize ("O2")

#define MAX_ROAD 2e8
#define MAX_DIST 1e6
#define N 205
#define HOP 10

std::ifstream fin ("input.txt");
std::ofstream fout ("output.txt");

std::pair < std::pair < int, int >, std::map < std::pair < int, int >, int > > task1(int initialState, int nofStates, int minLength, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates, int start) {
    std::vector < int > dist[2];
    std::map < std::pair < int, int >, int > parent;
    int vis[minLength + nofStates * 2 + 5] = {0};

    int phase = 0;
    dist[phase].push_back(initialState);
    
    for (int i = 0; i < minLength; ++i, phase ^= 1) {
        long long cnt = 0;
        dist[phase ^ 1].clear();
        memset(vis, 0, sizeof(vis));
 
        for (auto node : dist[phase]) {
            for (auto neighbor : translations[node]) {
                if (!vis[neighbor.first]) {
                    ++cnt;
                    vis[neighbor.first] = 1;
                    dist[phase ^ 1].push_back(neighbor.first);
                    parent[std::make_pair(neighbor.first, i + 1)] = node;
                }
            }

            if (cnt > 1500) {
                break;
            }
        }
    }

    for (int i = minLength; i <= minLength + nofStates * 2; ++i, phase ^= 1) {
        long long cnt = 0;
        dist[phase ^ 1].clear();
        memset(vis, 0, sizeof(vis));

        for (auto node : dist[phase]) {
            if (finalStates[node]) {
                return std::make_pair(std::make_pair(node, i), parent);
            } else {
                for (auto neighbor : translations[node]) {
                    if (!vis[neighbor.first]) {
                        ++cnt;
                        vis[neighbor.first] = 1;
                        dist[phase ^ 1].push_back(neighbor.first);
                        parent[std::make_pair(neighbor.first, i + 1)] = node;
                    }
                }
                if (cnt > 1500) {
                    break;
                }
            }
        }
    }

    return std::make_pair(std::make_pair(-1, MAX_ROAD), parent);
}

std::vector < int > filterStates(int initialState, int nofStates, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates) {
    std::vector < int > dist(nofStates + 5, MAX_DIST);
    std::queue < int > q;
    std::vector < bool > in(nofStates + 5, false);

    for (auto [node, seen] : finalStates) {
        dist[node] = 0;
        in[node] = true;
        q.push(node);
    }

    while (!q.empty()) {
        int node = q.front();
        in[node] = false;
        
        q.pop();

        for (auto neighbor : translations[node]) {
            if (dist[neighbor.first] > dist[node] + 1) {
                dist[neighbor.first] = dist[node] + 1;
                
                if (!in[neighbor.first]) {
                    q.push(neighbor.first);
                    in[neighbor.first] = true;
                }
            }
        }
    }

    return dist;
}

std::pair < std::string, int > goYoloFirst(int initialState, int nofStates, int minLength, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates) {
    std::string path = "";
    int lastNode = initialState;

    std::random_device rd;
    std::mt19937 g(rd());

    for (int i = 0; i < minLength / 2; ++i) {
        int neighbor = -1;
        std::shuffle(translations[lastNode].begin(), translations[lastNode].end(), g);

        do {
            ++neighbor;
        } while (translations[translations[lastNode][neighbor].first].size() == 0);

        path += translations[lastNode][neighbor].second;
        lastNode = translations[lastNode][neighbor].first;

    }

    return std::make_pair(path, lastNode);
}

std::pair < std::vector < int >, std::vector < int > > findShortestPath(int initialState, int nofStates, std::vector < std::pair < int, char > > *translations, std::vector < std::pair < int, char > > *translationsT, std::map < int, bool > finalStates) {
    std::queue < int > q;
    std::vector < int > shortestPath(nofStates + 5, MAX_DIST);
    bool in[nofStates + 5];

    shortestPath[initialState] = 0;
    q.push(initialState);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        in[node] = false;

        for (auto [neighbor, ch] : translations[node]) {
            if (shortestPath[neighbor] > shortestPath[node] + 1) {
                shortestPath[neighbor] = shortestPath[node] + 1;

                if (!in[neighbor]) {
                    in[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }
    }

    int mn = MAX_DIST, chosenEndNode = -1;

    for (auto [node, seen] : finalStates) {
        if (!seen) {
            continue;
        }
        
        if (shortestPath[node] < mn) {
            chosenEndNode = node;
        }
        mn = std::min(mn, shortestPath[node]);
    }

    std::vector < int > path;
    path.push_back(chosenEndNode);

    while(chosenEndNode != initialState) {
        for (auto [neighbor, ch] : translationsT[chosenEndNode]) {
            if (shortestPath[neighbor] == shortestPath[chosenEndNode] - 1) {
                chosenEndNode = neighbor;
                path.push_back(chosenEndNode);
                break;
            }
        }
    }

    return std::make_pair(path, shortestPath);
}

std::stack < int > st;
std::vector < std::vector < int > > sol;

bool in_stack[N];
int disc[N], temp, low[N];

void tarjan(int k, std::vector < int > *translations)
{
    disc[k] = low[k] = ++temp;
    in_stack[k] = true;
    st.push(k);
    for(auto v : translations[k]) {
        if(disc[v] == 0) {
            tarjan(v, translations);
            low[k] = std::min(low[k], low[v]);
        }
        else if(in_stack[v] == true) {
            low[k] = std::min(low[k], low[v]);
        }
    }
    if(low[k] == disc[k]) {
        std::vector < int > add;
        int node = k;
        do {
            node = st.top();
            add.push_back(node);
            in_stack[node] = false;
            st.pop();
        }
        while(node != k);
        sol.push_back(add);
    }
}

int find_cycle(int initialState, int nofStates, std::vector < int > *translations, std::vector < int > ctc) {
    std::queue < int > q;
    std::vector < int > dist(nofStates, MAX_DIST);
    std::vector < bool > in(nofStates, false);

    q.push(initialState);
    dist[initialState] = 0;

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        in[node] = false;

        for (auto neighbor : translations[node]) {
            if (ctc[initialState] == ctc[neighbor]) {
                if (dist[neighbor] > dist[node] + 1) {
                    dist[neighbor] = dist[node] + 1;

                    if (!in[neighbor]) {
                        q.push(neighbor);
                        in[neighbor] = true;
                    }
                } else if (neighbor == initialState) {
                    return dist[node] + 1;
                }
            }
        }
    }

    return -1;
}

int enrichWalk(int nofStates, int minLength, std::vector < int > cycleLength, int startLength, std::vector < int > shortestPath) {
    std::priority_queue < std::pair < int, int > > pq;
    int minAns = MAX_ROAD;
    std::vector < bool > dist(MAX_ROAD, false);

    dist[startLength] = true;
    for (size_t i = 0; i < shortestPath.size(); ++i) {
        if (cycleLength[shortestPath[i]] != -1) {
            pq.push(std::make_pair(startLength, shortestPath[i]));
        }
    }

    for (int i = startLength; i < minLength; ++i) {
        if (dist[i]) {
            for (auto node : shortestPath) {
                if (cycleLength[node] > 0) {
                    dist[i + cycleLength[node]] = true;
                }
            }
        }
    }

    for (int i = minLength; i <= MAX_ROAD; ++i) {
        if (dist[i]) {
            return i;
        }
    }

    return minAns;
}

std::vector < std::vector < std::vector < std::string > > > computePath(int initialState, int nofStates, std::vector < std::pair < int, char > > *translations, std::vector < bool > disabled, int maxFreq) {
    std::vector < std::vector < std::vector < std::string > > > pathStates(nofStates + 5, std::vector < std::vector < std::string > > (nofStates + 5, std::vector < std::string > (nofStates + 5, "")));
    std::queue < std::pair < int, std::string > > q;

    int vis[nofStates + 5];
    memset(vis, 0, sizeof(vis));

    for (int i = 1; i <= nofStates; ++i) {
        if (disabled[i]) {
            continue;
        }
        memset(vis, 0, sizeof(vis));

        q.push(std::make_pair(i, ""));

        while (!q.empty()) {
            auto [node, path] = q.front();
            q.pop();

            for (auto neighbor : translations[node]) {
                ++vis[neighbor.first];
                if (vis[neighbor.first] <= maxFreq) {
                    pathStates[i][neighbor.first][vis[neighbor.first]] = path + neighbor.second;
                }
                if (vis[neighbor.first] <= maxFreq * 10) {
                    q.push(std::make_pair(neighbor.first, path + neighbor.second));
                }
            }
        }
    }

    return pathStates;
}
std::pair < std::map < std::pair < int, int >, int > , std::pair < int, std::map < std::pair < int, int >, std::pair < int, int > > > > task2(int initialState, int nofStates, int minLength, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates, std::vector < std::vector < std::vector < std::string > > > pathStates, std::vector < int > finals, std::vector < bool > disabled) {
    std::priority_queue < std::pair < int, int > > pq;
    std::map < std::pair < int, int >, int > mp;
    std::map < std::pair < int, int >, std::pair < int, int > > parent;
    std::map < std::pair < int, int >, int > chosenLength;
    int vis[nofStates + 5] = {0};

    pq.push(std::make_pair(0, initialState));

    while (!pq.empty()) {
        auto [len, node] = pq.top();

        pq.pop();

        --vis[node];

        // std::cout << len << "\n";
        
        for (auto [neighbor, ch] : translations[node]) {
            if (vis[neighbor] > 500) {
                continue;
            }
            for (int j = HOP; j >= 1; j -= HOP - 1) {
                int transitionLength = (int)pathStates[node][neighbor][j].length();
                if (transitionLength == 0 || len + transitionLength > minLength || mp[std::make_pair(len + transitionLength, neighbor)] == 1) {
                    continue;
                }

                chosenLength[std::make_pair(len + transitionLength, neighbor)] = j;
                ++vis[neighbor];
                parent[std::make_pair(neighbor, len + transitionLength)] = std::make_pair(node, len);

                mp[std::make_pair(len + transitionLength, neighbor)] = 1;

                pq.push(std::make_pair(len + transitionLength, neighbor));

                if (finalStates[neighbor] == true && len + transitionLength == minLength) {
                    return std::make_pair(chosenLength, std::make_pair(neighbor, parent));
                }
                break;
            }
        }

        int ok = 0, cnt = 0;
        do {
            cnt++;
            int randNode = rand() % nofStates;
            if (!disabled[randNode]) {
                int transitionLength = pathStates[node][randNode][100].length();
                if (transitionLength > 0 && mp[std::make_pair(len + transitionLength, randNode)] == 0 && len + transitionLength <= minLength) {
                    chosenLength[std::make_pair(len + transitionLength, randNode)] = 100;

                    parent[std::make_pair(randNode, len + transitionLength)] = std::make_pair(node, len);

                    mp[std::make_pair(len + transitionLength, randNode)] = 1;

                    pq.push(std::make_pair(len + transitionLength, randNode));
                    ++ok;

                    if (len + transitionLength == minLength && finalStates[randNode]) {
                        return std::make_pair(chosenLength, std::make_pair(randNode, parent));
                    }
                }

                transitionLength = pathStates[node][randNode][1].length();
                if (transitionLength > 0 && mp[std::make_pair(len + transitionLength, randNode)] == 0 && len + transitionLength <= minLength) {
                    chosenLength[std::make_pair(len + transitionLength, randNode)] = 1;

                    parent[std::make_pair(randNode, len + transitionLength)] = std::make_pair(node, len);

                    mp[std::make_pair(len + transitionLength, randNode)] = 1;

                    pq.push(std::make_pair(len + transitionLength, randNode));
                    ++ok;

                    if (len + transitionLength == minLength && finalStates[randNode]) {
                        return std::make_pair(chosenLength, std::make_pair(randNode, parent));
                    }
                } 
            }
        }
        while (ok < 1 && cnt <= 100);

        for (auto neighbor : finals) {
            for (int j = HOP; j >= 1; j --) {
                int transitionLength = (int)pathStates[node][neighbor][j].length();
                if (transitionLength == 0 || len + transitionLength != minLength || mp[std::make_pair(len + transitionLength, neighbor)] == 1) {
                        continue;
                }
                parent[std::make_pair(neighbor, len + transitionLength)] = std::make_pair(node, len);
                chosenLength[std::make_pair(len + transitionLength, neighbor)] = j;

                return std::make_pair(chosenLength, std::make_pair(neighbor, parent));
            }
        }
    }

    return std::make_pair(chosenLength, std::make_pair(-1, parent));
}

void mult(int nofStates, int a[N][N], int b[N][N], int c[N][N]) {
    for (int i = 1; i <= nofStates; ++i) {
        for (int j = 1; j <= nofStates; ++j) {
            for (int k = 1; k <= nofStates; ++k) {
                c[i][j] += a[i][k] * b[k][j];
            }
            c[i][j] = (c[i][j] > 0);
        }
    }
}

int findSmallestPath(int initialState, int nofStates, int minLength, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates) {
    int power = minLength - 1;
    int init_adj[N][N];
    int adj[N][N];
    int sol[N][N];
    int aux[N][N];

    memset(adj, 0, sizeof(adj));
    memset(sol, 0, sizeof(sol));
    memset(aux, 0, sizeof(aux));

    for (int node = 1; node <= nofStates; ++node) {
        for (auto neighbor : translations[node]) {
            adj[node][neighbor.first] = 1;
            sol[node][neighbor.first] = 1;
            init_adj[node][neighbor.first] = 1;
        }
    }
    
    while (power) {
        if (power & 1) {
            memset(aux, 0, sizeof(aux));
            mult(nofStates, sol, adj, aux);
            memcpy(sol, aux, sizeof(aux));
        }

        memset(aux, 0, sizeof(aux));
        mult(nofStates, adj, adj, aux);
        memcpy(adj, aux, sizeof(aux));

        power >>= 1;
    }

    for (int i = 1; i <= nofStates; ++i) {
        for (auto [node, seen] : finalStates) {
            if (sol[initialState][node] > 0) {
                return minLength;
            }
        }

        memset(aux, 0, sizeof(aux));
        mult(nofStates, sol, init_adj, aux);
        memcpy(sol, aux, sizeof(aux));
        ++minLength;
    }

    return MAX_ROAD;
}

std::pair < std::pair < int, int >, std::map < std::pair < int, int >, std::pair < int, int > > > task3(int initialState, int nofStates, int minLength, std::vector < std::pair < int, char > > *translations, std::map < int, bool > finalStates, std::vector < int > finals) {
    std::priority_queue < std::pair < int, int > > pq;
    std::map < std::pair < int, int >, int > mp;
    std::map < std::pair < int, int >, std::pair < int, int > > parent;

    int minAns = MAX_ROAD, lastNode = -1;

    int vis[nofStates + 5];
    memset(vis, 0, sizeof(vis));

    pq.push(std::make_pair(0, initialState));

    while (!pq.empty()) {
        auto [len, node] = pq.top();
        pq.pop();
        
        // std::cout << len << "\n";

        --vis[node];

        if (len >= minLength) {
            if (len < minAns) {
                minAns = len;
                lastNode = node;
            }

            if (minAns == minLength) {
                return std::make_pair(std::make_pair(lastNode, minAns), parent);                
            }

            continue;
        }

        for (auto [neighbor, ch] : translations[node]) {
            if (mp[std::make_pair(len + 1, neighbor)] == 1 || vis[neighbor] > 100) {
                    continue;
            }

            ++vis[neighbor];
            parent[std::make_pair(neighbor, len + 1)] = std::make_pair(node, len);

            mp[std::make_pair(len + 1, neighbor)] = 1;

            pq.push(std::make_pair(len + 1, neighbor));

        }
    }

    return std::make_pair(std::make_pair(lastNode, minAns), parent);
}

int main() {
    srand(time(NULL));

    int taskId, nofStates, nofSymbols, nofFinalStates, minLength, initialState, nextState, finalState;
    std::map < int, bool > finalStates;
    std::vector < int > finals;

    fin >> taskId;
    fin >> nofStates >> nofSymbols >> nofFinalStates >> minLength;
    fin >> initialState;
    for (int i = 0; i < nofFinalStates; ++i) {
        fin >> finalState;
        finalStates[finalState] = true;
        finals.push_back(finalState);
    }

    std::vector < std::pair < int, char > > translations[nofStates + 5], translationsT[nofStates + 5];
    std::map < std::pair < int, int >, char > directTransitions;

    for (int i = 0; i < nofStates; ++i) {
        for (int j = 0; j < nofSymbols; ++j) {
            fin >> nextState;
            directTransitions[std::make_pair(i + 1, nextState)] = 'a' + j;
            translations[i + 1].push_back(std::make_pair(nextState, 'a' + j));
            translationsT[nextState].push_back(std::make_pair(i + 1, 'a' + j));
        }
    }

    std::vector < int > dist = filterStates(initialState, nofStates, translationsT, finalStates);

    std::vector < bool > disabled(nofStates + 5, false);
    for (int i = 1; i <= nofStates; ++i) {
        disabled[i] = dist[i] == MAX_DIST;
    }

    for (int i = 1; i <= nofStates; ++i) {
        for (std::vector < std::pair < int, char > >::iterator it = translations[i].begin(); it != translations[i].end(); ++it) {
            if (disabled[(*it).first]) {
                translations[i].erase(it);
                --it;
            }
        }
    }

    if (taskId == 1) {
        auto [pair, parent] = task1(initialState, nofStates, minLength, translations, finalStates, 0);
        auto [node, len] = pair;

        if (len == MAX_ROAD) {
            fout << -1 << "\n";
            return 0;
        }

        fout << len << "\n";

        std::string solPath = "";
        do {
            auto newNode = parent[std::make_pair(node, len)];
            solPath += directTransitions[std::make_pair(newNode, node)];

            node = newNode;
            --len; 
        } while (len != 0);

        reverse(solPath.begin(), solPath.end());
        fout << solPath << "\n";

    } else if (taskId == 2) {
        minLength = findSmallestPath(initialState, nofStates, minLength, translations, finalStates);
        if (minLength == MAX_ROAD) {
            fout << -1 << "\n";

            return 0;
        }
        fout << minLength << "\n";

        auto pathStates = computePath(initialState, nofStates, translations, disabled, HOP);
        
        auto [chosenLength, pair] = task2(initialState, nofStates, minLength, translations, finalStates, pathStates, finals, disabled);
        auto [node, parent] = pair;
        
        std::stack < std::string > path;
        do {
            auto [newNode, newMinLength] = parent[std::make_pair(node, minLength)];

            path.push(pathStates[newNode][node][chosenLength[std::make_pair(minLength, node)]]);

            node = newNode;
            minLength = newMinLength;
        } while (minLength != 0);

        std::string solPath = "";
        while (!path.empty()) {
            solPath += path.top();
            path.pop();
        }

        fout << solPath << "\n";
    } else if (taskId == 3) {
        
        return 0;
        auto pathStates = computePath(initialState, nofStates, translations, disabled, HOP);
        
        auto [path, dist] = findShortestPath(initialState, nofStates, translations, translationsT, finalStates);

        for (int i = 1; i <= nofStates; ++i) {
            if (disabled[i]) {
                continue;
            }
        }

        // auto [pair, parent] = task3(initialState, nofStates, minLength, translations, finalStates, finals);
        // auto [node, len] = pair;

        // std::cout << node << " " << len << "\n";
    }

    return 0;
}