// Copyright Bogdan Valentin-Razvan 311CA <bogdanvrazvan@gmail.com> 2021-2022

#ifndef SWAP_H
#define SWAP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define DIM 1005

void swap(int *ptr1, int *ptr2);

#endif

