// Copyright Bogdan Valentin-Razvan 311CA <bogdanvrazvan@gmail.com> 2021-2022

#ifndef FAIL_H
#define FAIL_H

#include "photo.h"
#include "save.h"
#include "exit.h"
#include "effects.h"

void F(FILE * in, struct mat *A, struct mat *B, char *l, struct fil *f, int k);

#endif
