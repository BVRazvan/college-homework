#include <iostream>
#include <vector>
#define PHASES 2
#define TYPES 3
using namespace std;

const int mod = 1000000007;

int type1(int x, int y) {
	int total_bits = x + y, phase = 0;

	long long dp[PHASES][min(x, y) + TYPES][TYPES];

	for (int i = 0; i <= 1; ++i) {
		for (int j = 0; j <= min(x, y); ++j) {
			for (int k = 0; k <= 1; ++k) {
				dp[i][j][k] = 0;
			}
		}
	}

	if (y <= x) {
		int zeroes;

		if (x > 0) {
			dp[phase][0][0] = 1;
		}
		if (y > 0) {
			dp[phase][1][1] = 1;
		}

		for (int bits = 2; bits <= total_bits; ++bits, phase ^= 1) {
			int mn = min(bits, y);

			for (int ones = mn; ones >= 0; --ones) {
				zeroes = bits - ones;

				if (zeroes > x) {
					break;
				}

				/* Pun un 0 dupa orice */
				if (zeroes > 0) {
					dp[phase ^ 1][ones][0] = dp[phase][ones][0];
					dp[phase ^ 1][ones][0] += dp[phase][ones][1];
					dp[phase ^ 1][ones][0] %= mod;
				}

				/* Pun un 1 dupa 0 */
				if (ones > 0) {
					dp[phase ^ 1][ones][1] = dp[phase][ones - 1][0];
					dp[phase ^ 1][ones][1] %= mod;
				}
			}
		}

		return (dp[phase][y][0] % mod + dp[phase][y][1] % mod) % mod;
	} else {
		int ones;

		if (x > 0) {
			dp[phase][1][0] = 1;
		}
		if (y > 0) {
			dp[phase][0][1] = 1;
		}

		for (int bits = 2; bits <= total_bits; ++bits, phase ^= 1) {
			int mn = min(bits, x);

			for (int zeroes = mn; zeroes >= 0; --zeroes) {
				ones = bits - zeroes;

				if (ones > y) {
					break;
				}

				/* Pun un 0 dupa orice */
				if (zeroes > 0) {
					dp[phase ^ 1][zeroes][0] = dp[phase][zeroes - 1][0];
					dp[phase ^ 1][zeroes][0] += dp[phase][zeroes - 1][1];
					dp[phase ^ 1][zeroes][0] %= mod;
				}
				/* Pun un 1 dupa 0 */
				if (ones > 0) {
					dp[phase ^ 1][zeroes][1] = dp[phase][zeroes][0];
					dp[phase ^ 1][zeroes][1] %= mod;
				}
			}
		}

		return (dp[phase][x][0] % mod + dp[phase][x][1] % mod) % mod;
	}
}

int type2(int x, int y) {
	int total_bits = x + y, phase = 0;
	long long dp[PHASES][min(x, y) + TYPES][TYPES];

	for (int i = 0; i <= 1; ++i) {
		for (int j = 0; j <= min(x, y); ++j) {
			for (int k = 0; k <= 2; ++k) {
				dp[i][j][k] = 0;
			}
		}
	}

	if (y <= x) {
		int zeroes;

		if (x > 0) {
			dp[phase][0][0] = 1;
		}
		if (y > 0) {
			dp[phase][1][1] = 1;
		}

		for (int bits = 2; bits <= total_bits; ++bits, phase ^= 1) {
			int mn = min(bits, y);

			for (int ones = mn; ones >= 0; --ones) {
				zeroes = bits - ones;

				if (zeroes > x) {
					break;
				}

				/* Pun un 0 dupa orice */
				if (zeroes > 0) {
					dp[phase ^ 1][ones][0] = dp[phase][ones][0];
					dp[phase ^ 1][ones][0] += dp[phase][ones][1];
					dp[phase ^ 1][ones][0] += dp[phase][ones][2];
					dp[phase ^ 1][ones][0] %= mod;
				}
				/* Pun un 1 dupa 0 */
				if (ones > 0) {
					dp[phase ^ 1][ones][1] = dp[phase][ones - 1][0];
				}
				/* Pun un 1 dupa 1 */
				if (ones > 1) {
					dp[phase ^ 1][ones][2] = dp[phase][ones - 1][1];
				}
			}
		}

		return (dp[phase][y][0] % mod + dp[phase][y][1] % mod
				+ dp[phase][y][2] % mod) % mod;
	} else {
		int ones;

		if (x > 0) {
			dp[phase][1][0] = 1;
		}
		if (y > 0) {
			dp[phase][0][1] = 1;
		}

		for (int bits = 2; bits <= total_bits; ++bits, phase ^= 1) {
			int mn = min(bits, x);

			for (int zeroes = mn; zeroes >= 0; --zeroes) {
				ones = bits - zeroes;

				if (ones > y) {
					break;
				}

				/* Pun un 0 dupa orice */
				if (zeroes > 0) {
					dp[phase ^ 1][zeroes][0] = dp[phase][zeroes - 1][0];
					dp[phase ^ 1][zeroes][0] += dp[phase][zeroes - 1][1];
					dp[phase ^ 1][zeroes][0] += dp[phase][zeroes - 1][2];
					dp[phase ^ 1][zeroes][0] %= mod;
				}
				/* Pun un 1 dupa 0 */
				if (ones > 0) {
					dp[phase ^ 1][zeroes][1] = dp[phase][zeroes][0];
				}
				/* Pun un 1 dupa 1 */
				if (ones > 1) {
					dp[phase ^ 1][zeroes][2] = dp[phase][zeroes][1];
				}
			}
		}

		return (dp[phase][x][0] % mod + dp[phase][x][1] % mod
				+ dp[phase][x][2] % mod) % mod;
	}
}

int main() {
    freopen("semnale.in", "r", stdin);
	freopen("semnale.out", "w", stdout);

	int sig_type, x, y;

	cin >> sig_type >> x >> y;

    switch (sig_type) {
		case 1:
			cout << type1(x, y);;
			break;
		case 2:
			cout << type2(x, y);
			break;
		default:
			cout << "wrong task number" << endl;
	}

    return 0;
}
