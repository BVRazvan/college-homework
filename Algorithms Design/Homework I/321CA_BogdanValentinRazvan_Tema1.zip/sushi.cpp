#include <iostream>
#include <algorithm>
#include <vector>
#define PHASES 2
using namespace std;

int task1(int n, int m, int x, vector <int>& p, vector <vector <int> >& g) {
	int total_price = n * x, phase = 0;
	vector < vector < int > > dp(PHASES, vector < int > (total_price + 1, 0));
	vector < int > sum_notes(m, 0);

	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			sum_notes[i] += g[j][i];
		}
	}

	for (int j = p[0]; j <= total_price; ++j) {
		dp[phase][j] = sum_notes[0];
	}
	for (int i = 1; i < m; ++i, phase ^= 1) {
		for (int j = 0; j <= total_price; ++j) {
			dp[phase ^ 1][j] = dp[phase][j];
			if (j >= p[i]) {
				dp[phase ^ 1][j] = max(dp[phase ^ 1][j],
										dp[phase][j - p[i]] + sum_notes[i]);
			}
		}
	}

	return dp[phase][total_price];
}

int task2(int n, int m, int x, vector <int> &p, vector <vector <int> > &g) {
	int total_price = n * x, phase = 0;
	vector < vector < int > > dp(PHASES, vector < int > (total_price + 1, 0));
	vector < int > sum_notes(m, 0);

	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			sum_notes[i] += g[j][i];
		}
	}

	for (int j = p[0]; j <= total_price; ++j) {
		dp[phase][j] = sum_notes[0];
		if (j >= 2 * p[0]) {
			dp[phase][j] = 2 * sum_notes[0];
		}
	}
	for (int i = 1; i < m; ++i, phase ^= 1) {
		for (int j = 0; j <= total_price; ++j) {
			dp[phase ^ 1][j] = dp[phase][j];
			if (j >= p[i]) {
				dp[phase ^ 1][j] = max(dp[phase ^ 1][j],
										dp[phase][j - p[i]] + sum_notes[i]);
			}
			if (j >= 2 * p[i]) {
				dp[phase ^ 1][j] = max(dp[phase ^ 1][j],
										dp[phase][j - 2 * p[i]] + 2 * sum_notes[i]);
			}
		}
	}

	return dp[phase][total_price];
}

int task3(int n, int m, int x, vector <int> &p, vector <vector <int> > &g) {
	int total_price = n * x, phase = 0;
	vector < vector < vector < int > > > dp(PHASES, vector < vector < int > >
								(total_price + 1, vector < int > (n + 1, 0)));
	vector < int > sum_notes(m, 0);

	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < n; ++j) {
			sum_notes[i] += g[j][i];
		}
	}

	for (int j = p[0]; j <= total_price; ++j) {
		dp[phase][j][1] = sum_notes[0];
		if (j >= 2 * p[0]) {
			dp[phase][j][2] = 2 * sum_notes[0];
		}
	}
	for (int i = 1; i < m; ++i, phase ^= 1) {
		for (int j = 0; j <= total_price; ++j) {
			for (int k = 1; k <= n && i + 1 >= (k + 1) / 2; ++k) {
				dp[phase ^ 1][j][k] = dp[phase][j][k];
				if (j >= p[i]) {
					dp[phase ^ 1][j][k] = max(dp[phase ^ 1][j][k],
									dp[phase][j - p[i]][k - 1] + sum_notes[i]);
				}
				if (j >= 2 * p[i] && k >= 2) {
					dp[phase ^ 1][j][k] = max(dp[phase ^ 1][j][k],
								dp[phase][j - 2 * p[i]][k - 2] + 2 * sum_notes[i]);
				}
			}
		}
	}

	int mx = 0;
	for (int i = 1; i <= n; ++i) {
		mx = max(mx, dp[phase][total_price][i]);
	}

	return mx;
}

int main() {
	freopen("sushi.in", "r", stdin);
	freopen("sushi.out", "w", stdout);

	int task;  // task number

	int n;  // number of friends
	int m;  // number of sushi types
	int x;  // how much each of you is willing to spend

	vector <int> prices;  // prices of each sushi type
	// the grades you and your friends gave to each sushi type
	vector <vector <int> > grades;

	cin >> task;
	cin >> n >> m >> x;

	prices.assign(m, 0);
	grades.assign(n, vector <int> (m, 0));

	// price of each sushi
	for(int i = 0; i < m; ++i) {
		cin >> prices[i];
	}

	// each friends rankings of sushi types
	for(int i = 0; i < n; ++i) {
		for(int j = 0; j < m; ++j) {
			cin >> grades[i][j];
		}
	}

	int ans = -1;

	switch(task) {
		case 1:
			ans = task1(n, m, x, prices, grades);
			break;
		case 2:
			ans = task2(n, m, x, prices, grades);
			break;
		case 3:
			ans = task3(n, m, x, prices, grades);
			break;
		default:
			cout << "wrong task number" << endl;
	}

	cout << ans << endl;

	return 0;
}
