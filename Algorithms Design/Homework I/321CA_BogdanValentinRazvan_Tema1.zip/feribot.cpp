#include <bits/stdc++.h>

using namespace std;

ifstream fin("feribot.in");
ofstream fout("feribot.out");

const int N = 1e5 + 5;

long long g[N];

bool try_with_fixed_weight(long long max_weight, int feribots, int cars) {
    long long cnt = 0;
    for (int i = 0; i < cars; ++i) {
        if (g[i] > max_weight || !feribots) {
            return false;
        }
        cnt += g[i];
        if (cnt > max_weight) {
            --feribots;
            cnt = g[i];
        }
    }

    return feribots > 0;
}

int main() {
    int n, k;

    fin >> n >> k;
    for (int i = 0; i < n; ++i) {
        fin >> g[i];
    }

    long long left = 1, right = 1LL * 1e17;

    /* Caut binar greutatea potrivita */
    while (left <= right) {
        long long mid = left + ((right - left) >> 1);

        if (try_with_fixed_weight(mid, k, n)) {
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    fout << left << "\n";

    return 0;
}
