/*
 * Acest schelet citește datele de intrare și scrie răspunsul generat de voi,
 * astfel că e suficient să completați cele două funcții.
 *
 * Scheletul este doar un punct de plecare, îl puteți modifica oricum doriți:
 * puteți schimba parametrii, reordona funcțiile etc.
 */

#include <cstdint>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int64_t SolveTask1(const vector<int>& a, const vector<int>& b) {
    /* Sortam elementele din cei doi vectori si le alegem pe cele mai mari N. */

    vector <int> c;
    for (int i = 0; i < (int)a.size(); ++i) {
        c.push_back(a[i]);
    }
    for (int i = 0; i < (int)b.size(); ++i) {
        c.push_back(b[i]);
    }
    sort(c.begin(), c.end());

    int64_t sol = 0;

    for (int i = (int)a.size(); i < 2 * (int)a.size(); ++i) {
        sol += 1LL * c[i];
    }
    return sol;
}

int64_t SolveTask2(const vector<int>& a, const vector<int>& b, int moves) {
    vector <int> c;
    vector <int> d;
    /**
     * Sortam elementele si gasim pragul ce stabileste fiecare element in ce
     * multime se afla(cele mai mici N elemente sau cele mai mari N elemente).
     */

    for (int i = 0; i < (int)a.size(); ++i) {
        c.push_back(a[i]);
    }
    for (int i = 0; i < (int)b.size(); ++i) {
        c.push_back(b[i]);
    }
    sort(c.begin(), c.end());

    int mn = c[(int)a.size()];
    int64_t sol = 0;

    /**
     * Adaugam minimul dintr-o pereche de tipul I si maximul dintr-o pereche
     * de tipul II intr-un vector auxiliar.
     */

    for (int i = 0; i < (int)a.size(); ++i) {
        sol += 1LL * max(a[i], b[i]);
        if (a[i] >= mn && b[i] >= mn) {
            d.push_back(min(a[i], b[i]));
        } else if (a[i] < mn && b[i] < mn) {
            d.push_back(max(a[i], b[i]));
        }
    }

    /**
     * Facem noi perechi pentru a maximiza solutia.
     */

    sort(d.begin(), d.end());
    for (int i = 0; i < min(moves, (int)d.size() / 2); ++i) {
        sol += 1LL * (d[(int)d.size() - 1 - i] - d[i]);
    }

    return sol;
}

vector<int> ReadVector(istream& is, int size) {
    vector<int> vec(size);
    for (auto& num : vec) {
        is >> num;
    }
    return vec;
}

int main() {
    ifstream fin("nostory.in");
    ofstream fout("nostory.out");

    int task;
    fin >> task;

    int n, moves;
    if (task == 1) {
        fin >> n;
    } else {
        fin >> n >> moves;
    }

    auto a = ReadVector(fin, n);
    auto b = ReadVector(fin, n);

    auto res = task == 1 ? SolveTask1(a, b) : SolveTask2(a, b, moves);
    fout << res << "\n";

    return 0;
}
