#include <bits/stdc++.h>
#define mod 1000000007

using namespace std;

ifstream fin("badgpt.in");
ofstream fout("badgpt.out");

long long sol[3][3], aux[3][3], add[3][3];

void mult(long long A[3][3], long long B[3][3], long long C[3][3]) {
    for (int i = 1; i <= 2; ++i) {
        for (int j = 1; j <= 2; ++j) {
            for (int k = 1; k <= 2; ++k) {
                C[i][j] = (C[i][j] + A[i][k] * B[k][j] % mod) % mod;
            }
        }
    }
}

void exp(long long n) {
    memset(add, 0, sizeof(add));
    memset(aux, 0, sizeof(aux));
    memset(sol, 0, sizeof(sol));

    add[1][1] = 0, add[1][2] = 1;
    add[2][1] = 1, add[2][2] = 1;
    sol[1][1] = 1, sol[2][2] = 1;
    while (n > 0) {
        if (n & 1) {
            memset(aux, 0, sizeof(aux));
            mult(sol, add, aux);
            memcpy(sol, aux, sizeof(aux));
        }
        memset(aux, 0, sizeof(aux));
        mult(add, add, aux);
        memcpy(add, aux, sizeof(aux));
        n >>= 1;
    }
}

int main() {
    string s;
    int sz;
    long long ans = 1;

    fin >> s;

    sz = s.length();
    for (int i = 0; i < sz; ++i) {
        if (s[i] == 'n' || s[i] == 'u') {
            long long nr = 0;

            ++i;
            while (s[i] >= '0' && s[i] <= '9') {
                nr = nr * 10LL + (s[i++] - '0');
            }
            --i;
            exp(nr);
            ans = (ans * ((sol[2][2] + mod) % mod)) % mod;

        } else {
            ++i;
            while (s[i] >= '0' && s[i] <= '9') {
                ++i;
            }
            --i;
        }
    }

    fout << ans << "\n";
    return 0;
}
