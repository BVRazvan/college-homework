#include <bits/stdc++.h>

std::ifstream fin("supercomputer.in");
std::ofstream fout("supercomputer.out");

const int N = 1e5 + 5;

std::vector < int > a[N], sol;
std::deque < int > dq;

int type[N], in[N], in_aux[N];

/**
 * Aplic algoritmul de sortare topologica, avand grija sa maximizez
 * pe cat posibil sirurile de tip 111..1111, 2222...2222, tinand
 * cont care este tipul ultimului nod care apare in sortare.
 * 
 * Avand in vedere ca primul nod din sortare poate fi de tip 1 sau 2,
 * aplic algoritmul de sortare pentru ambele variante.
 */
int solve(int node, int* in, int n) {
    int ans = 0;
    sol.clear();

    for (int i = 1; i <= n; ++i) {
        if (!in[i]) {
            if (type[i] == 1) {
                dq.push_back(i);
            } else {
                dq.push_front(i);
            }
        }
    }

    while (!dq.empty()) {
        if (type[node] == 1) {
            node = dq.back();
            dq.pop_back();
        } else {
            node = dq.front();
            dq.pop_front();
        }
        sol.push_back(node);

        for (auto v : a[node]) {
            --in[v];
            if (!in[v]) {
                if (type[v] == 1) {
                    dq.push_back(v);
                } else {
                    dq.push_front(v);
                }
            }
        }
    }

    for (size_t i = 0; i < sol.size() - 1; ++i) {
        ans += type[sol[i]] != type[sol[i + 1]];
    }

    return ans;
}

int main() {
    int n, m, x, y;

    fin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        fin >> type[i];
    }
    for (int i = 0; i < m; ++i) {
        fin >> x >> y;
        a[x].push_back(y);
        ++in[y];
        ++in_aux[y];
    }

    /**
     * Caut doua noduri vecine de tip diferit pentru a le da parametru,
     * la functia de rezolvare, daca nu exista inseamna ca toate sunt de
     * acelasi tip, iar raspunsul va fi 0.
     */
    for (int i = 1; i <= n; ++i) {
        if (type[i] != type[i + 1]) {
            fout << std::min(solve(i, in, n), solve(i + 1, in_aux, n)) << "\n";
            return 0;
        }
    }

    fout << 0 << "\n";

    return 0;
}
