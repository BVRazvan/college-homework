#include <bits/stdc++.h>

std::ifstream fin("ferate.in");
std::ofstream fout("ferate.out");

const int N = 1e5 + 5;

std::vector < int > a[N];
std::stack < int > st;
std::vector < std::vector < int > > sol;

bool in_stack[N], f[N], seen[N];
int disc[N], temp, low[N], mp_ctc[N], ans;

void tarjan(int k) {
    disc[k] = low[k] = ++temp;
    in_stack[k] = true;
    st.push(k);
    for (auto v : a[k]) {
        if (disc[v] == 0) {
            tarjan(v);
            low[k] = std::min(low[k], low[v]);
        } else if (in_stack[v] == true) {
            low[k] = std::min(low[k], low[v]);
        }
    }
    if (low[k] == disc[k]) {
        std::vector < int > add;
        int node = k;
        do {
            node = st.top();
            add.push_back(node);
            in_stack[node] = false;
            st.pop();
        } while (node != k);
        sol.push_back(add);
    }
}

/**
 * Dfs-ul initial de la sursa
 */
void dfs(int k) {
    f[k] = true;
    seen[mp_ctc[k]] = true;

    for (auto v : a[k]) {
        if (!f[v]) {
            dfs(v);
        }
    }
}

/**
 * Dfs-ul din nodurile in care nu poate ajunge sursa.
 * Daca am muchie de la o componenta tare conexa catre alta
 * in care nu s-a ajuns deja, inseamna ca e nevoie doar de o
 * muchie din sursa catre cele doua.
 */
void dfs_aux(int k) {
    f[k] = true;
    for (auto v : a[k]) {
        if (!f[v]) {
            dfs_aux(v);
        }
        if (mp_ctc[v] != mp_ctc[k] && !seen[mp_ctc[v]]) {
            seen[mp_ctc[v]] = true;
            --ans;
        }
    }
}

int main() {
    int n, m, source;

    fin >> n >> m >> source;
    for (int i = 1; i <= m; ++i) {
        int x, y;

        fin >> x >> y;
        a[x].push_back(y);
    }

    /**
     * Aplic algoritmul lui Tarjan pentru a afla componentele conexe, fiind nevoie,
     * in cel mai rau caz, de catre o muchie de la sursa catre fiecare componenta.
     * Pentru fiecare nod, mapez indicele componentei in care se afla.
     */
    for (int i = 1; i <= n; ++i) {
        if (disc[i] == 0) {
            tarjan(i);
        }
    }

    for (size_t i = 0; i < sol.size(); ++i) {
        for (size_t j = 0; j < sol[i].size(); ++j) {
            mp_ctc[sol[i][j]] = i + 1;
        }
    }

    ans = sol.size();

    /**
     * Aplicam dfs din sursa pentru a vedea nodurile accesibile si scad din solutie
     * toate componentele catre care pot ajunge.
     */
    dfs(source);

    for (auto v : sol) {
        for (auto w : v) {
            if (seen[mp_ctc[w]]) {
                --ans;
                break;
            }
        }
    }

    /**
     * Pentru componentele in care nu ajung incerc sa vad daca exista muchii catre
     * restul, astfel incat sa nu mai fie nevoie sa trag muchii redundante.
     */
    for (int i = 1; i <= n; ++i) {
        if (!f[i]) {
            dfs_aux(i);
        }
    }
    fout << ans << "\n";

    return 0;
}
