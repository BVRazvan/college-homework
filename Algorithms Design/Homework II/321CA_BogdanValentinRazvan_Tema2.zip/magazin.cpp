#include <bits/stdc++.h>

std::ifstream fin("magazin.in");
std::ofstream fout("magazin.out");

const int N = 1e5 + 5;

std::vector < int > a[N], sol;
bool f[N];
int pos[N], kids[N];

/**
 * Parcurgem graful pentru a construi vectorul de noduri vizitate si
 * pentru a numara pentru fiecare nod cate noduri are subgraful sau.
 */
void dfs(int k) {
    f[k] = true;
    sol.push_back(k);
    pos[k] = sol.size();

    for (auto v : a[k]) {
        if (!f[v]) {
            dfs(v);
        }
        kids[k] += kids[v] + 1;
    }
}

int main() {
    int n, q, x, y;

    fin >> n >> q;

    for (int i = 1; i <= n - 1; ++i) {
        fin >> x;

        a[x].push_back(i + 1);
    }
    for (int i = 1; i <= n; ++i) {
        std::sort(a[i].begin(), a[i].end());
    }
    for (int i = 1; i <= n; ++i) {
        if (!f[i]) {
            dfs(i);
        }
    }
    /**
     * Pentru a exista solutie avem nevoie ca nodul x sa aiba
     * cel putin y noduri in subgraf.
     */
    for (; q; --q) {
        fin >> x >> y;

        if (kids[x] < y) {
            fout << -1 << "\n";
        } else {
            fout << sol[pos[x] + y - 1] << "\n";
        }
    }

    return 0;
}
