#include <bits/stdc++.h>

using namespace std;

#define ll long long

ifstream fin("teleportare.in");
ofstream fout("teleportare.out");

void usain_bolt() {
    ios::sync_with_stdio(false);
    fin.tie(0);
}

const int N = 1e4 + 5;

vector < pair < ll, ll > > a[N], special[N];
multiset < pair < ll , int > > s;

ll d[N][155], ll_max[N];
int f[N];

/**
 * Dijkstra retinand costurile minime de rest 150.
 */
void dijkstra(int n) {
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j < 150; ++j) {
            d[i][j] = 1e18;
        }
    }
    d[1][0] = 0;
    s.insert({d[1][0], 1});
    while (!s.empty()) {
        auto x = s.begin();
        s.erase(s.begin());

        int v = x->second;
        ll cost = x->first;

        for (auto it : a[v]) {
            int to = it.first;
            ll len = it.second;
            ll mod = (cost + len) % 150LL;
            if (d[to][mod] > cost + len) {
                d[to][mod] = min(d[to][mod], cost + len);
                s.insert({cost + len, to});
            }
        }

        for (auto it : special[v]) {
            int to = it.first;
            ll required_mod = it.second;

            if (!(cost % required_mod)) {
                ll mod = (cost + 1) % 150LL;

                if (d[to][mod] > cost + 1) {
                    d[to][mod] = min(d[to][mod], cost + 1);
                    s.insert({cost + 1, to});
                }
            }
        }
    }
}

int main() {
    int n, m, k, x, y, t;

    fin >> n >> m >> k;
    for (int i = 0; i < m; ++i) {
        fin >> x >> y >> t;

        a[x].push_back({y, t});
        a[y].push_back({x, t});
    }
    for (int i = 0; i < k; ++i) {
        fin >> x >> y >> t;

        special[x].push_back({y, t});
        special[y].push_back({x, t});
    }
    dijkstra(n);

    ll mn = 1e18;
    for (int i = 0; i < 150; ++i) {
        mn = min(mn, d[n][i]);
    }

    fout << mn << "\n";

    return 0;
}
