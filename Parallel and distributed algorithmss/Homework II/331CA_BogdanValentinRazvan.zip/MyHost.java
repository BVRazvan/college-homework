/* Implement this class. */

import java.util.Comparator;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class MyHost extends Host {
    private static final int MAX_TASKS = 9999;
    private static final int MAX_SECONDS = 9999;
    private PriorityBlockingQueue < Task > tasksQueue = new PriorityBlockingQueue<>(MAX_TASKS, getCustomComparator());
    private AtomicLong workLeft = new AtomicLong();
    private AtomicInteger queueSize = new AtomicInteger();
    public Task actualTask;
    public double actualTime;
    public boolean shouldStop;

    @Override
    public void run() {
        while (!shouldStop) {
            actualTask = null;

            /*  Wait for a task to be available. */
            try {
                actualTask = tasksQueue.poll(MAX_SECONDS, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                return;
            }
            
            if (actualTask.isPreemptible()) {   
                while (true) {
                    if (!actualTask.isPreemptible())
                        break;

                    actualTime = Timer.getTimeDouble();
                    synchronized (actualTask) {
                        /* We have a new task, execute it, not before waiting for its start time, too. */
                        try {
                            this.actualTask.wait((long)(Math.max((double) actualTask.getStart() - Timer.getTimeDouble(), 0) * 1000 + actualTask.getLeft()));
                        } catch (InterruptedException e) {
                        }

                        double newActualTime = Timer.getTimeDouble();
                        
                        /* It might have been preempted */
                        if ((newActualTime - actualTime) * 1000 < actualTask.getLeft()) {
                            actualTask.setLeft(actualTask.getLeft() - (long)((newActualTime - actualTime) * 1000));
                            workLeft.addAndGet(-(long)((newActualTime - actualTime) * 1000));

                            if (actualTask.getLeft() > 0)
                                tasksQueue.add(actualTask);

                            actualTask = tasksQueue.poll();
                            continue;
                        }
                    }

                    /* Once the task finished, update the fields. */
                    actualTask.finish();
                    queueSize.decrementAndGet();
                    workLeft.addAndGet(-actualTask.getLeft());
                    break;
                }
            } 
            
            if (!actualTask.isPreemptible()) {
                /* We have a new task, execute it, not before waiting for its start time, too. */
                /* Because it is a non preemptive task, I decided to use sleep(). */
                actualTime = Timer.getTimeDouble();
                try {
                    Thread.sleep((long)(Math.max((double) actualTask.getStart() - Timer.getTimeDouble(), 0) * 1000 + actualTask.getLeft()));
                } catch (InterruptedException e) {
                    return;
                }
                
                /* Once the task finished, remove it and update the fields. */
                actualTask.finish();
                queueSize.decrementAndGet();
                workLeft.addAndGet(-actualTask.getLeft());
            }
        }
    }

    @Override
    public void addTask(Task task) {
        /* Update fields (actual thread's queue and increase workload). */
        tasksQueue.add(task);
        workLeft.addAndGet(task.getLeft());
        this.queueSize.incrementAndGet();
        if (actualTask == null)
            return;

        /* If actual running task can be preempted, notify it. */
        if (actualTask.isPreemptible()) {
            synchronized(actualTask) {
                if (actualTask != null && actualTask.getPriority() < task.getPriority()) {
                    this.actualTask.notify();
                }
            }
        }
    }

    @Override
    public int getQueueSize() {
        return queueSize.get();
    }

    @Override
    public long getWorkLeft() {
        return workLeft.get();
    }

    @Override
    public void shutdown() {
        shouldStop = true;
        this.interrupt();
    }

    public PriorityBlockingQueue < Task > getTasksQueue() {
        return tasksQueue;
    }

    private static Comparator<Task> getCustomComparator() {
        return (task1, task2) -> {
            int priorityDiff = task1.getPriority() - task2.getPriority();
            if (priorityDiff != 0)
                return -priorityDiff;
            else
                return task1.getId() - task2.getId();
        };
    }
}
