/* Implement this class. */

import java.util.List;

public class MyDispatcher extends Dispatcher {
    int lastChosenHost = 0;
    Host chosenHost;
    int cnt = 0;

    public MyDispatcher(SchedulingAlgorithm algorithm, List<Host> hosts) {
        super(algorithm, hosts);
    }

    @Override
    public void addTask(Task task) {

        switch (algorithm) {
            case ROUND_ROBIN:
                hosts.get(lastChosenHost).addTask(task);
                lastChosenHost = (lastChosenHost + 1) % hosts.size();
                break;

            case SHORTEST_QUEUE:
                chosenHost = hosts.get(0);
                int mnSize = chosenHost.getQueueSize();
                
                for (Host host : hosts) {
                    int queueSize = host.getQueueSize();
                    if (queueSize < mnSize) {
                        mnSize = host.getQueueSize();
                        chosenHost = host;
                    }
                }

                chosenHost.addTask(task);
                break;
                
            case SIZE_INTERVAL_TASK_ASSIGNMENT:
                switch (task.getType()) {
                    case SHORT:
                        hosts.get(0).addTask(task);
                        break;

                    case MEDIUM:
                        hosts.get(1).addTask(task);
                        break;

                    case LONG:
                        hosts.get(2).addTask(task);
                        break;

                    default:
                        break;
                }
                break;

            case LEAST_WORK_LEFT:
                chosenHost = hosts.get(0);
                long mnWork = chosenHost.getWorkLeft();
                double timeNow = Timer.getTimeDouble();
                if (((MyHost)chosenHost).actualTask != null)
                        mnWork -= (timeNow - ((MyHost)chosenHost).actualTime) * 1000;

                mnWork = Math.round(1.0 * mnWork / 1000);

                for (Host host : hosts) {
                    long workLeft = host.getWorkLeft();
                    if (((MyHost)host).actualTask != null)
                        workLeft -= (timeNow - ((MyHost)host).actualTime) * 1000;

                    workLeft = Math.round(1.0 * workLeft / 1000);
                    if (mnWork > workLeft) {
                        mnWork = workLeft;
                        chosenHost = host;
                    }
                }

                chosenHost.addTask(task);
                break;

            default:
                break;
        }
    }
}